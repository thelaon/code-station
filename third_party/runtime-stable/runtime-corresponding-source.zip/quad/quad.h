#ifndef CQ_QUAD_H
#define CQ_QUAD_H
#include <stddef.h>
#include <stdint.h>
typedef struct {
    uint64_t lo, hi;
} CQQuad;
void cq_qadd(CQQuad *, const CQQuad *, const CQQuad *);
void cq_qsub(CQQuad *, const CQQuad *, const CQQuad *);
void cq_qmul(CQQuad *, const CQQuad *, const CQQuad *);
void cq_qdiv(CQQuad *, const CQQuad *, const CQQuad *);
void cq_qneg(CQQuad *, const CQQuad *);
int cq_qcmp(const CQQuad *, const CQQuad *, int);
void cq_qfromi(CQQuad *, int64_t);
void cq_qfromu(CQQuad *, uint64_t);
void cq_qfromd(CQQuad *, double);
void cq_qfromf(CQQuad *, float);
int64_t cq_qtoi(const CQQuad *);
uint64_t cq_qtou(const CQQuad *);
double cq_qtod(const CQQuad *);
float cq_qtof(const CQQuad *);
void cq_qparse(CQQuad *, const char *, size_t, int, size_t *, int *, int *);
int cq_qformat(char *, int, const CQQuad *, int, int, int);
void cq_qscale(CQQuad *, const CQQuad *, int);
void cq_qsqrt(CQQuad *, const CQQuad *);
#endif
