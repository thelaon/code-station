/* Local binary128 integration, 2026-11-19. Arithmetic uses SoftFloat 3e.
 * Decimal/hex input uses exact integers and one ties-to-even rounding. */
#include "quad.h"
#include "softfloat-all.c"
static float128_t cq_soft(const CQQuad *a) {
    float128_t q;
    q.v[0] = a->lo;
    q.v[1] = a->hi;
    return q;
}
static void cq_bits(CQQuad *z, float128_t q) {
    z->lo = q.v[0];
    z->hi = q.v[1];
}
void cq_qadd(CQQuad *z, const CQQuad *a, const CQQuad *b) {
    cq_bits(z, f128_add(cq_soft(a), cq_soft(b)));
}
void cq_qsub(CQQuad *z, const CQQuad *a, const CQQuad *b) {
    cq_bits(z, f128_sub(cq_soft(a), cq_soft(b)));
}
void cq_qmul(CQQuad *z, const CQQuad *a, const CQQuad *b) {
    cq_bits(z, f128_mul(cq_soft(a), cq_soft(b)));
}
void cq_qdiv(CQQuad *z, const CQQuad *a, const CQQuad *b) {
    cq_bits(z, f128_div(cq_soft(a), cq_soft(b)));
}
void cq_qneg(CQQuad *z, const CQQuad *a) {
    z->lo = a->lo;
    z->hi = a->hi ^ 0x8000000000000000ull;
}
int cq_qcmp(const CQQuad *a, const CQQuad *b, int op) {
    float128_t x = cq_soft(a), y = cq_soft(b);
    switch (op) {
    case 0:
        return f128_eq(x, y);
    case 1:
        return !f128_eq(x, y);
    case 2:
        return f128_lt(x, y);
    case 3:
        return f128_le(x, y);
    case 4:
        return f128_lt(y, x);
    default:
        return f128_le(y, x);
    }
}
void cq_qfromi(CQQuad *z, int64_t a) {
    cq_bits(z, i64_to_f128(a));
}
void cq_qfromu(CQQuad *z, uint64_t a) {
    cq_bits(z, ui64_to_f128(a));
}
void cq_qfromd(CQQuad *z, double a) {
    union {
        double d;
        uint64_t u;
    } v;
    float64_t f;
    v.d = a;
    f.v = v.u;
    cq_bits(z, f64_to_f128(f));
}
void cq_qfromf(CQQuad *z, float a) {
    union {
        float f;
        uint32_t u;
    } v;
    float32_t f;
    v.f = a;
    f.v = v.u;
    cq_bits(z, f32_to_f128(f));
}
int64_t cq_qtoi(const CQQuad *a) {
    return f128_to_i64(cq_soft(a), softfloat_round_minMag, 0);
}
uint64_t cq_qtou(const CQQuad *a) {
    return f128_to_ui64(cq_soft(a), softfloat_round_minMag, 0);
}
double cq_qtod(const CQQuad *a) {
    union {
        double d;
        uint64_t u;
    } v;
    v.u = f128_to_f64(cq_soft(a)).v;
    return v.d;
}
float cq_qtof(const CQQuad *a) {
    union {
        float f;
        uint32_t u;
    } v;
    v.u = f128_to_f32(cq_soft(a)).v;
    return v.f;
}
void cq_qsqrt(CQQuad *z, const CQQuad *a) {
    cq_bits(z, f128_sqrt(cq_soft(a)));
}
void cq_qscale(CQQuad *z, const CQQuad *a, int amount) {
    uint64_t sig_hi = a->hi & 0xffffffffffffull, sig_lo = a->lo;
    int exponent = (int)((a->hi >> 48) & 32767);
    int sign = (int)(a->hi >> 63);
    struct exp32_sig128 normalized;
    if (exponent == 32767 || (!exponent && !sig_hi && !sig_lo)) {
        *z = *a;
        return;
    }
    if (!exponent) {
        normalized = softfloat_normSubnormalF128Sig(sig_hi, sig_lo);
        exponent = normalized.exp;
        sig_hi = normalized.sig.v64;
        sig_lo = normalized.sig.v0;
    } else
        sig_hi |= 0x1000000000000ull;
    if (amount > 32768)
        amount = 32768;
    if (amount < -32768)
        amount = -32768;
    cq_bits(z, softfloat_roundPackToF128(sign, exponent + amount - 1, sig_hi, sig_lo, 0));
}
static int cq_space(int c) {
    return c == ' ' || (c >= 9 && c <= 13);
}
static int cq_digit(int c) {
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'z')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'Z')
        return c - 'A' + 10;
    return -1;
}
#define CQ_FP_WORDS 4096
#define CQ_FP_DIGITS 12000
typedef struct {
    unsigned short w[CQ_FP_WORDS];
    int n;
} CQFpBig;
static void cq_fp_zero(CQFpBig *a) {
    a->n = 1;
    a->w[0] = 0;
}
static void cq_fp_trim(CQFpBig *a) {
    while (a->n > 1 && a->w[a->n - 1] == 0)
        --a->n;
}
static void cq_fp_muladd(CQFpBig *a, unsigned int m, unsigned int add) {
    int i;
    unsigned int carry = add;
    for (i = 0; i < a->n; ++i) {
        unsigned int v = a->w[i] * m + carry;
        a->w[i] = (unsigned short)v;
        carry = v >> 16;
    }
    if (carry)
        a->w[a->n++] = (unsigned short)carry;
}
static void cq_fp_shift(CQFpBig *a, int shift) {
    int words = shift / 16, bits = shift % 16, i;
    unsigned int carry = 0;
    if (a->n == 1 && a->w[0] == 0)
        return;
    if (words) {
        for (i = a->n - 1; i >= 0; --i)
            a->w[i + words] = a->w[i];
        for (i = 0; i < words; ++i)
            a->w[i] = 0;
        a->n += words;
    }
    if (bits) {
        for (i = words; i < a->n; ++i) {
            unsigned int v = ((unsigned int)a->w[i] << bits) | carry;
            a->w[i] = (unsigned short)v;
            carry = v >> 16;
        }
        if (carry)
            a->w[a->n++] = (unsigned short)carry;
    }
}
static int cq_fp_cmp(const CQFpBig *a, const CQFpBig *b) {
    int i;
    if (a->n != b->n)
        return a->n > b->n ? 1 : -1;
    for (i = a->n - 1; i >= 0; --i)
        if (a->w[i] != b->w[i])
            return a->w[i] > b->w[i] ? 1 : -1;
    return 0;
}
static void cq_fp_sub(CQFpBig *a, const CQFpBig *b) {
    int i;
    unsigned int borrow = 0;
    for (i = 0; i < a->n; ++i) {
        unsigned int x = a->w[i], y = (i < b->n ? b->w[i] : 0) + borrow;
        a->w[i] = (unsigned short)(x - y);
        borrow = x < y;
    }
    cq_fp_trim(a);
}
static int cq_fp_bitlen(const CQFpBig *a) {
    unsigned int v = a->w[a->n - 1];
    int bits = 0;
    while (v) {
        ++bits;
        v >>= 1;
    }
    return (a->n - 1) * 16 + bits;
}
static CQQuad cq_round(CQFpBig *num, int power, int decimal, int sticky, int *range) {
    CQFpBig den, a, b, t;
    CQQuad q = {0, 0}, inf = {0, 0x7fff000000000000ull};
    int d, e, i, unit, shift, cmp;
    cq_fp_zero(&den);
    den.w[0] = 1;
    if (decimal) {
        if (power > 0)
            for (i = 0; i < power; ++i)
                cq_fp_muladd(num, 5, 0);
        else
            for (i = 0; i < -power; ++i)
                cq_fp_muladd(&den, 5, 0);
    }
    d = cq_fp_bitlen(num) - cq_fp_bitlen(&den);
    if (d >= 0) {
        t = den;
        cq_fp_shift(&t, d);
        cmp = cq_fp_cmp(num, &t);
    } else {
        t = *num;
        cq_fp_shift(&t, -d);
        cmp = cq_fp_cmp(&t, &den);
    }
    if (cmp < 0)
        --d;
    e = d + power;
    if (e > 16383) {
        *range = 1;
        return inf;
    }
    if (e < -16495) {
        *range = 1;
        return q;
    }
    unit = (e < -16382 ? -16382 : e) - 112;
    shift = power - unit;
    a = *num;
    b = den;
    if (shift >= 0)
        cq_fp_shift(&a, shift);
    else
        cq_fp_shift(&b, -shift);
    d = cq_fp_bitlen(&a) - cq_fp_bitlen(&b);
    for (i = d; i >= 0; --i) {
        t = b;
        cq_fp_shift(&t, i);
        if (cq_fp_cmp(&a, &t) >= 0) {
            cq_fp_sub(&a, &t);
            if (i >= 64)
                q.hi |= 1ull << (i - 64);
            else
                q.lo |= 1ull << i;
        }
    }
    t = a;
    cq_fp_shift(&t, 1);
    cmp = cq_fp_cmp(&t, &b);
    if (cmp > 0 || (cmp == 0 && (sticky || (q.lo & 1)))) {
        ++q.lo;
        if (!q.lo)
            ++q.hi;
    }
    if (e < -16382) {
        if (cq_fp_bitlen(&a) || sticky)
            *range = 1;
        return q;
    }
    if (q.hi & 0x2000000000000ull) {
        q.lo = (q.lo >> 1) | (q.hi << 63);
        q.hi >>= 1;
        ++e;
    }
    if (e > 16383) {
        *range = 1;
        return inf;
    }
    q.hi = (q.hi & 0xffffffffffffull) | ((uint64_t)(e + 16383) << 48);
    return q;
}
static int cq_fp_peek(const char *s, size_t at, size_t limit) {
    return at < limit && s[at] ? (unsigned char)s[at] : -1;
}
static int cq_fp_lower(int c) {
    return c >= 'A' && c <= 'Z' ? c + 32 : c;
}
static int cq_fp_word(const char *s, size_t at, size_t limit, const char *word) {
    int n = 0;
    while (word[n] && cq_fp_lower(cq_fp_peek(s, at + n, limit)) == word[n])
        ++n;
    return n;
}
/* scan=1 consumes the longest prefix of a matching input item, even when an
 * exponent/special token is incomplete. strto*=0 instead rolls back to the
 * longest complete subject sequence. Both return the same correctly rounded
 * bits for complete tokens. Scanner skips whitespace before calling this. */
static CQQuad cq_parse_value(const char *s, size_t limit, int scan, size_t *used,
                             int *ok, int *range) {
    CQFpBig num;
    size_t p = 0, numeric, exponent_at, suffix;
    long long fraction = 0, dropped = 0, power, order;
    int negative = 0, hex = 0, point = 0, digits = 0, stored = 0, sticky = 0;
    int c, digit, base, exponent = 0, exponent_negative = 0, n;
    CQQuad signbit = {0, 0}, bits, inf = {0, 0x7fff000000000000ull};
    *used = 0;
    *ok = 0;
    if (!scan)
        while (cq_space(cq_fp_peek(s, p, limit)))
            ++p;
    c = cq_fp_peek(s, p, limit);
    if (c == '+' || c == '-') {
        negative = c == '-';
        ++p;
    }
    signbit.hi = negative ? 0x8000000000000000ull : 0;
    n = cq_fp_word(s, p, limit, "inf");
    if (n) {
        if (n < 3) {
            if (scan)
                *used = p + n;
            return (CQQuad){0, 0};
        }
        p += 3;
        n = cq_fp_word(s, p, limit, "inity");
        if (n == 5)
            p += 5;
        else if (scan && n) {
            *used = p + n;
            return (CQQuad){0, 0};
        }
        *used = p;
        *ok = 1;
        inf.hi |= signbit.hi;
        return inf;
    }
    n = cq_fp_word(s, p, limit, "nan");
    if (n) {
        if (n < 3) {
            if (scan)
                *used = p + n;
            return (CQQuad){0, 0};
        }
        p += 3;
        if (cq_fp_peek(s, p, limit) == '(') {
            suffix = p++;
            while ((c = cq_fp_lower(cq_fp_peek(s, p, limit))) == '_' || (c >= '0' && c <= '9') ||
                   (c >= 'a' && c <= 'z'))
                ++p;
            if (cq_fp_peek(s, p, limit) == ')')
                ++p;
            else if (scan) {
                *used = p;
                return (CQQuad){0, 0};
            } else
                p = suffix;
        }
        *used = p;
        *ok = 1;
        return (CQQuad){0, signbit.hi | 0x7fff800000000000ull};
    }
    numeric = p;
    if (cq_fp_peek(s, p, limit) == '0' && cq_fp_lower(cq_fp_peek(s, p + 1, limit)) == 'x') {
        hex = 1;
        p += 2;
    }
again:
    cq_fp_zero(&num);
    base = hex ? 16 : 10;
    for (;;) {
        c = cq_fp_peek(s, p, limit);
        if (c == '.' && !point) {
            point = 1;
            ++p;
            continue;
        }
        digit = cq_digit(c);
        if (digit < 0 || digit >= base)
            break;
        ++digits;
        ++p;
        if (point)
            ++fraction;
        if (digit || stored) {
            if (stored < CQ_FP_DIGITS) {
                cq_fp_muladd(&num, base, digit);
                ++stored;
            } else {
                ++dropped;
                if (digit)
                    sticky = 1;
            }
        }
    }
    if (!digits) {
        if (hex && !scan) {
            hex = 0;
            point = 0;
            p = numeric;
            goto again;
        }
        if (scan)
            *used = p;
        return (CQQuad){0, 0};
    }
    c = cq_fp_lower(cq_fp_peek(s, p, limit));
    if (c == (hex ? 'p' : 'e')) {
        exponent_at = p++;
        c = cq_fp_peek(s, p, limit);
        if (c == '+' || c == '-') {
            exponent_negative = c == '-';
            ++p;
        }
        n = 0;
        while ((c = cq_fp_peek(s, p, limit)) >= '0' && c <= '9') {
            if (exponent < 100000000)
                exponent = exponent * 10 + c - '0';
            ++n;
            ++p;
        }
        if (!n) {
            if (scan) {
                *used = p;
                return (CQQuad){0, 0};
            }
            p = exponent_at;
        }
    }
    *used = p;
    *ok = 1;
    if (!stored)
        return signbit;
    power = (exponent_negative ? -(long long)exponent : (long long)exponent) -
            fraction * (hex ? 4 : 1) + dropped * (hex ? 4 : 1);
    /* Cheap magnitude bounds prevent enormous exponent work. */
    if (hex)
        order = (long long)cq_fp_bitlen(&num) - 1 + power;
    else
        order = (long long)stored - 1 + power;
    if (order > (hex ? 16384 : 4933)) {
        *range = 1;
        inf.hi |= signbit.hi;
        return inf;
    }
    if (order < (hex ? -16496 : -4967)) {
        *range = 1;
        return signbit;
    }
    bits = cq_round(&num, (int)power, !hex, sticky, range);
    bits.hi |= signbit.hi;
    return bits;
}

void cq_qparse(CQQuad *z, const char *s, size_t limit, int scan, size_t *used, int *ok,
               int *range) {
    *range = 0;
    *z = cq_parse_value(s, limit, scan, used, ok, range);
}

/* CODE-STATION MODIFICATION NOTICE
File: quad/quad.c
Local update 2026-11-20: unify floating output, release conversion temporaries, reject narrowing fallback,
share comparison mapping, simplify exact decimal expansion and select used SoftFloat implementations.
Existing copyright, license notices and exceptions remain applicable.
END CODE-STATION MODIFICATION NOTICE */
