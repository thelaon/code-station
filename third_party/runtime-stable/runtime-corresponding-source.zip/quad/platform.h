#define LITTLEENDIAN 1
#define SOFTFLOAT_FAST_INT64 1
#define INLINE_LEVEL 0
#define INLINE static inline
#define THREAD_LOCAL
