/* Exact binary128 decimal expansion and nearest-even presentation.
 * Local integration, 2026-11-19. The coefficient uses base 10000 words. */
#include "quad.h"
typedef struct {
    unsigned int w[3000];
    int n;
} CQDecimal;
static void cq_decimal_mul(CQDecimal *a, unsigned int m, unsigned int carry) {
    int i;
    for (i = 0; i < a->n; ++i) {
        unsigned int v = a->w[i] * m + carry;
        a->w[i] = v % 10000;
        carry = v / 10000;
    }
    while (carry) {
        a->w[a->n++] = carry % 10000;
        carry /= 10000;
    }
}
static int cq_decimal_digits(char *s, const CQQuad *q, int *scale) {
    CQDecimal a;
    uint64_t hi = q->hi & 0xffffffffffffull, lo = q->lo;
    int e = (int)((q->hi >> 48) & 32767), bit, exp, n = 0, i, j;
    unsigned int word;
    a.n = 1;
    a.w[0] = 0;
    if (e)
        hi |= 0x1000000000000ull;
    if (!hi && !lo) {
        s[0] = '0';
        s[1] = 0;
        *scale = 0;
        return 1;
    }
    exp = (e ? e - 16383 : -16382) - 112;
    /* Cancel powers of two exactly before expanding in base ten. This avoids
     * constructing thousands of zero digits for zero, integers and fractions
     * such as 1.25, and preserves the nearest-even rounding below. */
    while (!(lo & 1)) {
        lo = (lo >> 1) | (hi << 63);
        hi >>= 1;
        ++exp;
    }
    for (bit = 112; bit >= 0; bit -= 16) {
        unsigned int chunk = (unsigned int)(bit >= 64 ? hi >> (bit - 64) : lo >> bit);
        cq_decimal_mul(&a, 65536, chunk & 65535);
    }
    *scale = exp < 0 ? -exp : 0;
    if (exp < 0) {
        for (i = -exp; i >= 6; i -= 6)
            cq_decimal_mul(&a, 15625, 0);
        while (i--)
            cq_decimal_mul(&a, 5, 0);
    } else {
        for (i = exp; i >= 16; i -= 16)
            cq_decimal_mul(&a, 65536, 0);
        if (i)
            cq_decimal_mul(&a, 1u << i, 0);
    }
    word = a.w[a.n - 1];
    {
        char rev[4];
        j = 0;
        while (word) {
            rev[j++] = (char)('0' + word % 10);
            word /= 10;
        }
        while (j)
            s[n++] = rev[--j];
    }
    for (i = a.n - 2; i >= 0; --i) {
        word = a.w[i];
        s[n + 3] = (char)('0' + word % 10);
        word /= 10;
        s[n + 2] = (char)('0' + word % 10);
        word /= 10;
        s[n + 1] = (char)('0' + word % 10);
        s[n] = (char)('0' + word / 10);
        n += 4;
    }
    s[n] = 0;
    return n;
}
static void cq_out_char(char *s, int cap, int *n, int c) {
    if (*n < cap - 1)
        s[*n] = (char)c;
    ++*n;
}
static void cq_out_exp(char *s, int cap, int *n, int e, int upper, int hex) {
    char rev[8];
    int j = 0;
    cq_out_char(s, cap, n, hex ? (upper ? 'P' : 'p') : (upper ? 'E' : 'e'));
    cq_out_char(s, cap, n, e < 0 ? '-' : '+');
    if (e < 0)
        e = -e;
    do {
        rev[j++] = (char)('0' + e % 10);
        e /= 10;
    } while (e);
    if (!hex && j < 2)
        rev[j++] = '0';
    while (j)
        cq_out_char(s, cap, n, rev[--j]);
}
int cq_qformat(char *out, int cap, const CQQuad *q, int spec, int precision, int alt) {
    char digits[12050];
    int upper = spec >= 'A' && spec <= 'Z', lower = upper ? spec + 32 : spec;
    int n, scale, e, cut, i, round, sticky, pos = 0, fraction, scientific = 0;
    uint64_t abs_hi = q->hi & 0x7fffffffffffffffull;
    if ((abs_hi >> 48) == 32767) {
        const char *word = (q->lo || (abs_hi & 0xffffffffffffull)) ? (upper ? "NAN" : "nan")
                                                                   : (upper ? "INF" : "inf");
        for (i = 0; i < 3; ++i)
            cq_out_char(out, cap, &pos, word[i]);
        if (cap > 0)
            out[pos < cap ? pos : cap - 1] = 0;
        return pos;
    }
    if (lower == 'a') {
        uint64_t high = abs_hi & 0xffffffffffffull, low = q->lo;
        int exponent = (int)(abs_hi >> 48), count = precision < 0 ? 28 : precision;
        int leading = exponent != 0;
        e = exponent ? exponent - 16383 : -16382;
        if (!high && !low && !leading)
            e = 0;
        for (i = 0; i < 28; ++i) {
            int b = 108 - i * 4;
            digits[i] = (char)(b >= 64 ? (high >> (b - 64)) & 15 : (low >> b) & 15);
        }
        if (count < 28) {
            sticky = 0;
            for (i = count + 1; i < 28; ++i)
                sticky |= digits[i];
            round = digits[count] > 8 ||
                    (digits[count] == 8 && (sticky || ((count ? digits[count - 1] : leading) & 1)));
            if (round) {
                i = count - 1;
                while (i >= 0 && digits[i] == 15)
                    digits[i--] = 0;
                if (i >= 0)
                    ++digits[i];
                else
                    ++leading;
            }
        }
        if (precision < 0)
            while (count && digits[count - 1] == 0)
                --count;
        cq_out_char(out, cap, &pos, '0');
        cq_out_char(out, cap, &pos, upper ? 'X' : 'x');
        cq_out_char(out, cap, &pos, '0' + leading);
        if (count || alt)
            cq_out_char(out, cap, &pos, '.');
        for (i = 0; i < count; ++i) {
            int v = i < 28 ? digits[i] : 0;
            cq_out_char(out, cap, &pos, v < 10 ? '0' + v : (upper ? 'A' : 'a') + v - 10);
        }
        cq_out_exp(out, cap, &pos, e, upper, 1);
        if (cap > 0)
            out[pos < cap ? pos : cap - 1] = 0;
        return pos;
    }
    if (precision < 0)
        precision = 6;
    if (lower == 'g' && precision == 0)
        precision = 1;
    n = cq_decimal_digits(digits, q, &scale);
    e = n - scale - 1;
    cut = lower == 'f' ? e + 1 + precision : lower == 'e' ? precision + 1 : precision;
    if (cut < n) {
        sticky = 0;
        for (i = cut + 1 < 0 ? 0 : cut + 1; i < n; ++i)
            sticky |= digits[i] != '0';
        round = cut >= 0 &&
                (digits[cut] > '5' ||
                 (digits[cut] == '5' && (sticky || (cut > 0 && ((digits[cut - 1] - '0') & 1)))));
        if (cut <= 0) {
            digits[0] = round ? '1' : '0';
            n = 1;
            e = round ? e + 1 : 0;
        } else {
            n = cut;
            if (round) {
                i = n - 1;
                while (i >= 0 && digits[i] == '9')
                    digits[i--] = '0';
                if (i >= 0)
                    ++digits[i];
                else {
                    digits[0] = '1';
                    n = 1;
                    ++e;
                }
            }
        }
    }
    if (lower == 'g')
        scientific = e < -4 || e >= precision;
    else
        scientific = lower == 'e';
    fraction = lower == 'g' ? (scientific ? precision - 1 : precision - e - 1) : precision;
    if (lower == 'g' && !alt) {
        int last = n - 1;
        while (last > 0 && digits[last] == '0')
            --last;
        fraction = scientific ? last : last - e;
        if (fraction < 0)
            fraction = 0;
    }
    if (scientific) {
        cq_out_char(out, cap, &pos, digits[0]);
        if (fraction || alt)
            cq_out_char(out, cap, &pos, '.');
        for (i = 1; i <= fraction; ++i)
            cq_out_char(out, cap, &pos, i < n ? digits[i] : '0');
        cq_out_exp(out, cap, &pos, e, upper, 0);
    } else {
        if (e < 0)
            cq_out_char(out, cap, &pos, '0');
        else
            for (i = 0; i <= e; ++i)
                cq_out_char(out, cap, &pos, i < n ? digits[i] : '0');
        if (fraction || alt)
            cq_out_char(out, cap, &pos, '.');
        for (i = 1; i <= fraction; ++i) {
            int at = e + i;
            cq_out_char(out, cap, &pos, at >= 0 && at < n ? digits[at] : '0');
        }
    }
    if (cap > 0)
        out[pos < cap ? pos : cap - 1] = 0;
    return pos;
}

/* CODE-STATION MODIFICATION NOTICE
File: quad/quad-format.c
Local update 2026-11-20: unify floating output, release conversion temporaries, reject narrowing fallback,
share comparison mapping, simplify exact decimal expansion and select used SoftFloat implementations.
Existing copyright, license notices and exceptions remain applicable.
END CODE-STATION MODIFICATION NOTICE */
