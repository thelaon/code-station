#ifndef _SIGNAL_H
#define _SIGNAL_H
typedef int sig_atomic_t;
typedef void (*sighandler_t)(int);
#define SIGABRT 6
#define SIGFPE 8
#define SIGILL 4
#define SIGINT 2
#define SIGSEGV 11
#define SIGTERM 15
#define SIG_DFL ((sighandler_t)0)
/* Wasm function pointers are table indices: reserve negative sentinels. */
#define SIG_IGN ((sighandler_t)-2)
#define SIG_ERR ((sighandler_t)-1)
sighandler_t signal(int sig, sighandler_t handler);
int raise(int sig);
#endif

/* CODE-STATION MODIFICATION NOTICE
File: _tcc_test/tcc-source/include/signal.h
This is a locally modified Code Station project version, not an unmodified upstream file.
Upstream basis: 44670/tcc-wasm @ 8bff9fbc019a3008395eec4cda6e90752fb88ed9.
Changes: C stdio and C-locale completion, per-application exit/signal callbacks, static inline emission, aligned frames and aggregate variadic arguments; historical binary128 and judge fixes retained.
Development records include batches dated 2026-10-20 through 2026-10-27;
these are batch evidence, not asserted dates of every individual edit.
This notice and the annotated source edition were prepared on 2026-11-20.
Existing copyright, license notices and exceptions remain applicable.
See licenses/LOCAL-MODIFICATIONS-NOTICE.txt and evidence/source-map.json.
END CODE-STATION MODIFICATION NOTICE */
