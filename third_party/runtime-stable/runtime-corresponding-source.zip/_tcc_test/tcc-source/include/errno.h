#ifndef _ERRNO_H
#define _ERRNO_H

#define EPERM   1
#define ENOENT  2
#define EIO     5
#define EBADF   9
#define ENOMEM 12
#define EINVAL 22
#define EMFILE 24
#define EFBIG  27
#define ENOSPC 28
#define ENAMETOOLONG 36
#define ENOSYS 52

int *__errno_location(void);
#define errno (*__errno_location())

#endif

/* CODE-STATION MODIFICATION NOTICE
File: errno.h
This is a locally modified Code Station project version, not an unmodified upstream file.
Upstream basis: 44670/tcc-wasm @ 8bff9fbc019a3008395eec4cda6e90752fb88ed9.
Changes: Declared errno constants used by the file limits.
Development records include batches dated 2026-10-20 through 2026-10-27;
these are batch evidence, not asserted dates of every individual edit.
This notice and the annotated source edition were prepared on 2026-10-31.
Existing copyright, license notices and exceptions remain applicable.
See licenses/LOCAL-MODIFICATIONS-NOTICE.txt and evidence/source-map.json.
2026-11-13: Declared errno constants used by the file limits.
END CODE-STATION MODIFICATION NOTICE */
