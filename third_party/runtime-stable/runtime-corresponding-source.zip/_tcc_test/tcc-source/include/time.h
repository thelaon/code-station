#ifndef _TIME_H
#define _TIME_H

#include <stddef.h>

#ifndef __TCC_TIME_T_TYPEDEF
#define __TCC_TIME_T_TYPEDEF
typedef int time_t;
#endif

#ifndef __TCC_CLOCK_T_TYPEDEF
#define __TCC_CLOCK_T_TYPEDEF
typedef int clock_t;
#endif

#define CLOCKS_PER_SEC 1000

struct tm {
    int tm_sec;
    int tm_min;
    int tm_hour;
    int tm_mday;
    int tm_mon;
    int tm_year;
    int tm_wday;
    int tm_yday;
    int tm_isdst;
};

clock_t clock(void);
time_t time(time_t *t);
double difftime(time_t end, time_t beginning);
time_t mktime(struct tm *tm);
struct tm *localtime(const time_t *t);
struct tm *gmtime(const time_t *t);
size_t strftime(char *s, size_t max, const char *fmt, const struct tm *tm);
char *asctime(const struct tm *tm);
char *ctime(const time_t *t);

#endif

/* CODE-STATION MODIFICATION NOTICE
File: _tcc_test/tcc-source/include/time.h
This is a locally modified Code Station project version, not an unmodified upstream file.
Upstream basis: 44670/tcc-wasm @ 8bff9fbc019a3008395eec4cda6e90752fb88ed9.
Changes: Time-function declarations.
Development records include batches dated 2026-10-20 through 2026-10-27;
these are batch evidence, not asserted dates of every individual edit.
This notice and the annotated source edition were prepared on 2026-10-31.
Existing copyright, license notices and exceptions remain applicable.
See licenses/LOCAL-MODIFICATIONS-NOTICE.txt and evidence/source-map.json.
END CODE-STATION MODIFICATION NOTICE */
