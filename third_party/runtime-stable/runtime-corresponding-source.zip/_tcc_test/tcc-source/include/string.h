#ifndef _STRING_H
#define _STRING_H

#include <stddef.h>

void *memset(void *dst, int c, size_t n);
void *memcpy(void *dst, const void *src, size_t n);
void *memmove(void *dst, const void *src, size_t n);
int memcmp(const void *a, const void *b, size_t n);
void *memchr(const void *s, int c, size_t n);

size_t strlen(const char *s);
size_t strnlen(const char *s, size_t max);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, size_t n);
char *strcat(char *dst, const char *src);
char *strncat(char *dst, const char *src, size_t n);
char *strdup(const char *s);
int strcmp(const char *a, const char *b);
int strncmp(const char *a, const char *b, size_t n);
int strcoll(const char *a, const char *b);
char *strchr(const char *s, int c);
char *strrchr(const char *s, int c);
char *strstr(const char *haystack, const char *needle);
char *strpbrk(const char *s, const char *accept);
size_t strspn(const char *s, const char *accept);
size_t strcspn(const char *s, const char *reject);
char *strtok(char *s, const char *delim);
char *strtok_r(char *s, const char *delim, char **saveptr);
char *strerror(int errnum);
size_t strxfrm(char *dst, const char *src, size_t n);

#endif

/* CODE-STATION MODIFICATION NOTICE
File: _tcc_test/tcc-source/include/string.h
This is a locally modified Code Station project version, not an unmodified upstream file.
Upstream basis: 44670/tcc-wasm @ 8bff9fbc019a3008395eec4cda6e90752fb88ed9.
Changes: C stdio and C-locale completion, per-application exit/signal callbacks, static inline emission, aligned frames and aggregate variadic arguments; historical binary128 and judge fixes retained.
Development records include batches dated 2026-10-20 through 2026-10-27;
these are batch evidence, not asserted dates of every individual edit.
This notice and the annotated source edition were prepared on 2026-11-20.
Existing copyright, license notices and exceptions remain applicable.
See licenses/LOCAL-MODIFICATIONS-NOTICE.txt and evidence/source-map.json.
END CODE-STATION MODIFICATION NOTICE */
