#ifndef _MATH_H
#define _MATH_H

#define HUGE_VAL 1e10000
#define HUGE_VALF 1e10000f
#define HUGE_VALL 1e10000L
#define INFINITY HUGE_VALF
#define NAN (0.0f / 0.0f)

double fabs(double x);
double sin(double x);
double sinh(double x);
double cos(double x);
double cosh(double x);
double tan(double x);
double tanh(double x);
double asin(double x);
double acos(double x);
double atan(double x);
double atan2(double y, double x);
double ceil(double x);
double floor(double x);
double fmod(double x, double y);
double modf(double x, double *iptr);
double sqrt(double x);
double pow(double x, double y);
double log(double x);
double log10(double x);
double exp(double x);
double frexp(double x, int *exp);
double ldexp(double x, int exp);
long double ldexpl(long double x, int exp);
long double sqrtl(long double x);
long double fabsl(long double x);

#endif

/* CODE-STATION MODIFICATION NOTICE
File: _tcc_test/tcc-source/include/math.h
This is a locally modified Code Station project version, not an unmodified upstream file.
Upstream basis: 44670/tcc-wasm @ 8bff9fbc019a3008395eec4cda6e90752fb88ed9.
Changes: C stdio and C-locale completion, per-application exit/signal callbacks, static inline emission, aligned frames and aggregate variadic arguments; historical binary128 and judge fixes retained.
Development records include batches dated 2026-10-20 through 2026-10-27;
these are batch evidence, not asserted dates of every individual edit.
This notice and the annotated source edition were prepared on 2026-11-20.
Existing copyright, license notices and exceptions remain applicable.
See licenses/LOCAL-MODIFICATIONS-NOTICE.txt and evidence/source-map.json.
END CODE-STATION MODIFICATION NOTICE */
