/*
 * Small freestanding wasm32 runtime provider.
 *
 * This file is intentionally compiled by wasm32-tcc itself.  It is not a
 * complete hosted libc; it is the stable first provider module for TCC-emitted
 * wasm programs: memory allocation, byte/string primitives, and buffered stdio
 * hooks with no JavaScript runtime dependency.
 */

typedef unsigned int size_t;
typedef __builtin_va_list va_list;

#define va_start(ap, last) __builtin_va_start(ap, last)
#define va_arg(ap, type) __builtin_va_arg(ap, type)
#define va_end(ap) (void)(ap)
#define va_copy(dst, src) ((dst) = (src))

#define RT_STDIN 0
#define RT_STDOUT 1
#define RT_STDERR 2
#define RT_FILE_MEM 3

#define RT_ENOENT  (-2)
#define RT_EBADF  (-9)
#define RT_EINVAL (-22)
#define RT_ENOSPC (-28)
#define RT_ENOSYS (-52)

#define RT_STDIO_CAP 1048576u
#define RT_NULL (~0u)
#define RT_FMT_TO_BUFFER 0
#define RT_FMT_TO_STDOUT 1
#define RT_FMT_TO_STDERR 2

#define EOF (-1)
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#define RAND_MAX 2147483647
#define CLOCKS_PER_SEC 1000

struct __wasm_FILE {
    int fd;
    int eof;
    int err;
    int has_ungot;
    unsigned char ungot;
    unsigned char *buf;
    size_t len;
    size_t pos;
    size_t cap;
    int writable;
    char *path;
    int memstream;
    char **memstream_ptr;
    size_t *memstream_len;
};

typedef struct __wasm_FILE FILE;

struct RtBlock {
    size_t size;
    size_t next;
    int free;
};

struct RtFileData {
    char *path;
    unsigned char *data;
    size_t len;
    struct RtFileData *next;
};

static unsigned char *rt_stdin_buf;
static unsigned char *rt_stdout_buf;
static unsigned char *rt_stderr_buf;
static size_t rt_stdin_len;
static size_t rt_stdin_pos;
static size_t rt_stdout_used;
static size_t rt_stderr_used;

static size_t rt_heap_start;
static size_t rt_heap_end;
static size_t rt_heap_first;
static int rt_heap_ready;
static int rt_errno;
static int rt_stdio_hosted;
static unsigned rt_rand_state = 1;
static FILE rt_file_stdin = { RT_STDIN, 0, 0, 0, 0 };
static FILE rt_file_stdout = { RT_STDOUT, 0, 0, 0, 0 };
static FILE rt_file_stderr = { RT_STDERR, 0, 0, 0, 0 };
static struct RtFileData *rt_files;

int rt_write(int fd, const void *src, size_t len);
int rt_host_read(int fd, void *dst, size_t len);
int rt_host_write(int fd, const void *src, size_t len);
int rt_host_isatty(int fd);
void rt_host_exit(int code);
void *malloc(size_t size);
void free(void *ptr);
void *realloc(void *ptr, size_t size);
int vsnprintf(char *dst, size_t n, const char *fmt, va_list ap);
int vsscanf(const char *src, const char *fmt, va_list ap);
double strtod(const char *s, char **endptr);
static unsigned long long rt_parse_fp(const char *, size_t, int, int, size_t *, int *);

int *__errno_location(void)
{
    return &rt_errno;
}

static size_t rt_align8(size_t n)
{
    return (n + 7u) & ~7u;
}

static size_t rt_align8_down(size_t n)
{
    return n & ~7u;
}

static size_t rt_block_header_size(void)
{
    return rt_align8(sizeof(struct RtBlock));
}

void *memset(void *dst, int c, size_t n)
{
    unsigned char *d = dst;
    size_t i;
    for (i = 0; i < n; ++i)
        d[i] = (unsigned char)c;
    return dst;
}

void *memcpy(void *dst, const void *src, size_t n)
{
    unsigned char *d = dst;
    const unsigned char *s = src;
    size_t i;
    for (i = 0; i < n; ++i)
        d[i] = s[i];
    return dst;
}

void *memmove(void *dst, const void *src, size_t n)
{
    unsigned char *d = dst;
    const unsigned char *s = src;
    size_t i;

    if (d == s || n == 0)
        return dst;
    if (d < s || d >= s + n) {
        for (i = 0; i < n; ++i)
            d[i] = s[i];
    } else {
        for (i = n; i != 0; --i)
            d[i - 1] = s[i - 1];
    }
    return dst;
}

int memcmp(const void *a, const void *b, size_t n)
{
    const unsigned char *p = a;
    const unsigned char *q = b;
    size_t i;
    for (i = 0; i < n; ++i) {
        if (p[i] != q[i])
            return (int)p[i] - (int)q[i];
    }
    return 0;
}

size_t strlen(const char *s)
{
    size_t n = 0;
    while (s[n])
        ++n;
    return n;
}

char *strcpy(char *dst, const char *src)
{
    char *ret = dst;
    while ((*dst++ = *src++))
        ;
    return ret;
}

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) {
        ++a;
        ++b;
    }
    return (unsigned char)*a - (unsigned char)*b;
}

int strncmp(const char *a, const char *b, size_t n)
{
    size_t i;
    for (i = 0; i < n; ++i) {
        unsigned char ca = (unsigned char)a[i];
        unsigned char cb = (unsigned char)b[i];
        if (ca != cb || ca == 0)
            return (int)ca - (int)cb;
    }
    return 0;
}

void *memchr(const void *s, int c, size_t n)
{
    const unsigned char *p = s;
    size_t i;
    for (i = 0; i < n; ++i)
        if (p[i] == (unsigned char)c)
            return (void *)(p + i);
    return 0;
}

char *strncpy(char *dst, const char *src, size_t n)
{
    size_t i;
    for (i = 0; i < n && src[i]; ++i)
        dst[i] = src[i];
    for (; i < n; ++i)
        dst[i] = 0;
    return dst;
}

char *strcat(char *dst, const char *src)
{
    strcpy(dst + strlen(dst), src);
    return dst;
}

char *strncat(char *dst, const char *src, size_t n)
{
    char *d = dst + strlen(dst);
    size_t i;
    for (i = 0; i < n && src[i]; ++i)
        d[i] = src[i];
    d[i] = 0;
    return dst;
}

int strcoll(const char *a, const char *b)
{
    return strcmp(a, b);
}

char *strchr(const char *s, int c)
{
    unsigned char ch = (unsigned char)c;
    for (;; ++s) {
        if ((unsigned char)*s == ch)
            return (char *)s;
        if (!*s)
            return 0;
    }
}

char *strrchr(const char *s, int c)
{
    const char *last = 0;
    unsigned char ch = (unsigned char)c;
    for (;; ++s) {
        if ((unsigned char)*s == ch)
            last = s;
        if (!*s)
            return (char *)last;
    }
}

char *strstr(const char *haystack, const char *needle)
{
    size_t nlen = strlen(needle);
    if (nlen == 0)
        return (char *)haystack;
    while (*haystack) {
        if (*haystack == *needle && !strncmp(haystack, needle, nlen))
            return (char *)haystack;
        ++haystack;
    }
    return 0;
}

char *strdup(const char *s)
{
    size_t len = strlen(s);
    char *copy = malloc(len + 1);
    if (!copy)
        return 0;
    memcpy(copy, s, len + 1);
    return copy;
}

size_t strnlen(const char *s, size_t max)
{
    size_t n = 0;
    while (n < max && s[n])
        ++n;
    return n;
}

char *strpbrk(const char *s, const char *accept)
{
    for (; *s; ++s)
        if (strchr(accept, *s))
            return (char *)s;
    return 0;
}

size_t strspn(const char *s, const char *accept)
{
    size_t n = 0;
    while (s[n] && strchr(accept, s[n]))
        ++n;
    return n;
}

size_t strcspn(const char *s, const char *reject)
{
    size_t n = 0;
    while (s[n] && !strchr(reject, s[n]))
        ++n;
    return n;
}

char *strtok_r(char *s, const char *delim, char **saveptr)
{
    char *end;

    if (!s)
        s = *saveptr;
    s += strspn(s, delim);
    if (!*s) {
        *saveptr = s;
        return 0;
    }
    end = s + strcspn(s, delim);
    if (*end) {
        *end++ = 0;
        *saveptr = end;
    } else {
        *saveptr = end;
    }
    return s;
}

char *strtok(char *s, const char *delim)
{
    static char *saveptr;
    return strtok_r(s, delim, &saveptr);
}

char *strerror(int errnum)
{
    switch (errnum) {
    case 0: return "success";
    case 2: return "no such file";
    case 5: return "i/o error";
    case 9: return "bad file descriptor";
    case 12: return "out of memory";
    case 22: return "invalid argument";
    case 28: return "no space";
    case 52: return "not implemented";
    default: return "error";
    }
}

static int rt_ascii(int c)
{
    return c & 255;
}

int isdigit(int c) { c = rt_ascii(c); return c >= '0' && c <= '9'; }
int islower(int c) { c = rt_ascii(c); return c >= 'a' && c <= 'z'; }
int isupper(int c) { c = rt_ascii(c); return c >= 'A' && c <= 'Z'; }
int isalpha(int c) { return islower(c) || isupper(c); }
int isalnum(int c) { return isalpha(c) || isdigit(c); }
int iscntrl(int c) { c = rt_ascii(c); return c < 32 || c == 127; }
int isspace(int c) { c = rt_ascii(c); return c == ' ' || (c >= '\t' && c <= '\r'); }
int isxdigit(int c) { c = rt_ascii(c); return isdigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
int ispunct(int c) { c = rt_ascii(c); return c > 32 && c < 127 && !isalnum(c); }
int isblank(int c) { c = rt_ascii(c); return c == ' ' || c == '\t'; }
int isgraph(int c) { c = rt_ascii(c); return c > 32 && c < 127; }
int isprint(int c) { c = rt_ascii(c); return c >= 32 && c < 127; }
int tolower(int c) { return isupper(c) ? c + ('a' - 'A') : c; }
int toupper(int c) { return islower(c) ? c - ('a' - 'A') : c; }

static struct RtBlock *rt_block_at(size_t addr)
{
    return (struct RtBlock *)addr;
}

static void rt_heap_reset(void)
{
    rt_stdin_buf = 0;
    rt_stdout_buf = 0;
    rt_stderr_buf = 0;
    rt_stdin_len = 0;
    rt_stdin_pos = 0;
    rt_stdout_used = 0;
    rt_stderr_used = 0;
    rt_heap_start = 0;
    rt_heap_end = 0;
    rt_heap_first = 0;
    rt_heap_ready = 0;
}

static void rt_heap_split(size_t addr, size_t size)
{
    struct RtBlock *b = rt_block_at(addr);
    struct RtBlock *n;
    size_t hdr = rt_block_header_size();
    size_t n_addr;

    if (b->size < size + hdr + 8u)
        return;
    n_addr = addr + hdr + size;
    n = rt_block_at(n_addr);
    n->size = b->size - size - hdr;
    n->next = b->next;
    n->free = 1;
    b->size = size;
    b->next = n_addr;
}

static void rt_heap_coalesce(void)
{
    size_t addr = rt_heap_first;

    while (addr != RT_NULL) {
        struct RtBlock *b = rt_block_at(addr);
        if (b->free && b->next != RT_NULL) {
            struct RtBlock *n = rt_block_at(b->next);
            if (n->free) {
                b->size += rt_block_header_size() + n->size;
                b->next = n->next;
                continue;
            }
        }
        addr = b->next;
    }
}

void *malloc(size_t size)
{
    size_t addr;
    size_t hdr = rt_block_header_size();

    if (!rt_heap_ready)
        return 0;
    if (size == 0)
        size = 1;
    size = rt_align8(size);
    for (addr = rt_heap_first; addr != RT_NULL; addr = rt_block_at(addr)->next) {
        struct RtBlock *b = rt_block_at(addr);
        if (b->free && b->size >= size) {
            rt_heap_split(addr, size);
            b->free = 0;
            return (void *)(addr + hdr);
        }
    }
    return 0;
}

void free(void *ptr)
{
    size_t addr;
    struct RtBlock *b;

    if (!ptr || !rt_heap_ready)
        return;
    addr = (size_t)ptr;
    if (addr < rt_heap_start + rt_block_header_size() || addr >= rt_heap_end)
        return;
    addr -= rt_block_header_size();
    b = rt_block_at(addr);
    b->free = 1;
    rt_heap_coalesce();
}

void *calloc(size_t nmemb, size_t size)
{
    void *ptr;
    size_t total;

    if (size != 0 && nmemb > (~0u) / size)
        return 0;
    total = nmemb * size;
    ptr = malloc(total);
    if (ptr)
        memset(ptr, 0, total);
    return ptr;
}

void *realloc(void *ptr, size_t size)
{
    size_t old_size;
    size_t addr;
    void *new_ptr;
    struct RtBlock *b;

    if (!ptr)
        return malloc(size);
    if (size == 0) {
        free(ptr);
        return 0;
    }
    if (!rt_heap_ready)
        return 0;

    addr = (size_t)ptr - rt_block_header_size();
    b = rt_block_at(addr);
    old_size = b->size;
    size = rt_align8(size);
    if (size <= old_size) {
        rt_heap_split(addr, size);
        return ptr;
    }

    new_ptr = malloc(size);
    if (!new_ptr)
        return 0;
    memcpy(new_ptr, ptr, old_size);
    free(ptr);
    return new_ptr;
}

int rt_init_heap(size_t start, size_t end)
{
    struct RtBlock *b;
    size_t hdr = rt_block_header_size();

    if (rt_heap_ready)
        return RT_EINVAL;
    start = rt_align8(start);
    end = rt_align8_down(end);
    if (end <= start + hdr + 3u * RT_STDIO_CAP)
        return RT_EINVAL;

    rt_heap_start = start;
    rt_heap_end = end;
    rt_heap_first = start;
    b = rt_block_at(rt_heap_first);
    b->size = end - start - hdr;
    b->next = RT_NULL;
    b->free = 1;
    rt_heap_ready = 1;

    rt_stdin_buf = malloc(RT_STDIO_CAP);
    rt_stdout_buf = malloc(RT_STDIO_CAP);
    rt_stderr_buf = malloc(RT_STDIO_CAP);
    if (!rt_stdin_buf || !rt_stdout_buf || !rt_stderr_buf) {
        rt_heap_reset();
        return RT_ENOSPC;
    }
    return 0;
}

int rt_heap_initialized(void)
{
    return rt_heap_ready;
}

int rt_stdio_capacity(void)
{
    return RT_STDIO_CAP;
}

static int rt_stdio_ready(void)
{
    return rt_stdin_buf && rt_stdout_buf && rt_stderr_buf;
}

void rt_stdio_reset(void)
{
    rt_stdin_len = 0;
    rt_stdin_pos = 0;
    rt_stdout_used = 0;
    rt_stderr_used = 0;
    rt_file_stdin.eof = 0;
    rt_file_stdin.err = 0;
    rt_file_stdin.has_ungot = 0;
    rt_file_stdout.err = 0;
    rt_file_stderr.err = 0;
}

void rt_stdio_set_hosted(int hosted)
{
    rt_stdio_hosted = hosted != 0;
}

int rt_stdio_hosted_enabled(void)
{
    return rt_stdio_hosted;
}

static void rt_stdin_compact(void)
{
    size_t remaining;

    if (!rt_stdio_ready())
        return;
    if (rt_stdin_pos == 0)
        return;
    if (rt_stdin_pos >= rt_stdin_len) {
        rt_stdin_len = 0;
        rt_stdin_pos = 0;
        return;
    }
    remaining = rt_stdin_len - rt_stdin_pos;
    memmove(rt_stdin_buf, rt_stdin_buf + rt_stdin_pos, remaining);
    rt_stdin_len = remaining;
    rt_stdin_pos = 0;
}

int rt_stdin_set(const void *src, size_t len)
{
    if (!rt_stdio_ready())
        return RT_EINVAL;
    if (!src && len)
        return RT_EINVAL;
    if (len > RT_STDIO_CAP)
        return RT_ENOSPC;
    if (len)
        memcpy(rt_stdin_buf, src, len);
    rt_stdin_len = len;
    rt_stdin_pos = 0;
    return (int)len;
}

int rt_stdin_append(const void *src, size_t len)
{
    if (!rt_stdio_ready())
        return RT_EINVAL;
    if (!src && len)
        return RT_EINVAL;
    rt_stdin_compact();
    if (len > RT_STDIO_CAP - rt_stdin_len)
        return RT_ENOSPC;
    if (len)
        memcpy(rt_stdin_buf + rt_stdin_len, src, len);
    rt_stdin_len += len;
    return (int)len;
}

int rt_stdin_remaining(void)
{
    if (!rt_stdio_ready())
        return 0;
    return (int)(rt_stdin_len - rt_stdin_pos);
}

int rt_stdout_ptr(void)
{
    return (int)rt_stdout_buf;
}

int rt_stdout_len(void)
{
    return (int)rt_stdout_used;
}

void rt_stdout_clear(void)
{
    rt_stdout_used = 0;
}

int rt_stderr_ptr(void)
{
    return (int)rt_stderr_buf;
}

int rt_stderr_len(void)
{
    return (int)rt_stderr_used;
}

void rt_stderr_clear(void)
{
    rt_stderr_used = 0;
}

static char *rt_strdup_n(const char *s, size_t len)
{
    char *p = malloc(len + 1);
    if (!p)
        return 0;
    if (len)
        memcpy(p, s, len);
    p[len] = 0;
    return p;
}

static struct RtFileData *rt_file_find(const char *path)
{
    struct RtFileData *it;

    if (!path)
        return 0;
    for (it = rt_files; it; it = it->next)
        if (strcmp(it->path, path) == 0)
            return it;
    return 0;
}

static int rt_file_store(const char *path, const void *src, size_t len)
{
    struct RtFileData *file;
    unsigned char *data;

    if (!path)
        return RT_EINVAL;
    file = rt_file_find(path);
    if (!file) {
        file = malloc(sizeof *file);
        if (!file)
            return RT_ENOSPC;
        memset(file, 0, sizeof *file);
        file->path = rt_strdup_n(path, strlen(path));
        if (!file->path) {
            free(file);
            return RT_ENOSPC;
        }
        file->next = rt_files;
        rt_files = file;
    }
    data = malloc(len ? len : 1);
    if (!data)
        return RT_ENOSPC;
    if (len)
        memcpy(data, src, len);
    free(file->data);
    file->data = data;
    file->len = len;
    return (int)len;
}

int rt_file_add(const char *path, const void *src, size_t len)
{
    return rt_file_store(path, src, len);
}

static int rt_file_append(FILE *f, const void *src, size_t len)
{
    unsigned char *p;
    size_t cap;

    if (!f || !f->writable)
        return RT_EBADF;
    if (!src && len)
        return RT_EINVAL;
    if (len > ((size_t)-1) - f->len)
        return RT_ENOSPC;
    if (f->len + len > f->cap) {
        cap = f->cap ? f->cap : 64;
        while (cap < f->len + len) {
            if (cap > ((size_t)-1) / 2) {
                cap = f->len + len;
                break;
            }
            cap *= 2;
        }
        p = realloc(f->buf, cap);
        if (!p)
            return RT_ENOSPC;
        f->buf = p;
        f->cap = cap;
    }
    if (len)
        memcpy(f->buf + f->len, src, len);
    f->len += len;
    f->pos = f->len;
    return (int)len;
}

static int rt_buffer_write(unsigned char *buf, size_t *buf_len,
                           const void *src, size_t len)
{
    size_t room;
    size_t n;

    if (!buf)
        return RT_EINVAL;
    if (!src && len)
        return RT_EINVAL;
    room = RT_STDIO_CAP - *buf_len;
    if (room == 0 && len)
        return RT_ENOSPC;
    n = len;
    if (n > room)
        n = room;
    if (n)
        memcpy(buf + *buf_len, src, n);
    *buf_len += n;
    return (int)n;
}

struct RtFmtOut {
    int mode;
    char *buf;
    size_t cap;
    size_t len;
    int error;
};

static void rt_fmt_putc(struct RtFmtOut *out, int ch)
{
    unsigned char c = (unsigned char)ch;

    if (out->error)
        return;
    if (out->mode == RT_FMT_TO_STDOUT) {
        if (rt_write(RT_STDOUT, &c, 1) != 1)
            out->error = 1;
    } else if (out->cap == RT_NULL) {
        out->buf[out->len] = (char)c;
    } else if (out->len + 1u < out->cap) {
        out->buf[out->len] = (char)c;
    }
    ++out->len;
}

static void rt_fmt_write(struct RtFmtOut *out, const char *s, size_t len)
{
    size_t i;
    for (i = 0; i < len; ++i)
        rt_fmt_putc(out, s[i]);
}

static size_t rt_strnlen(const char *s, size_t max)
{
    size_t n = 0;
    while (n < max && s[n])
        ++n;
    return n;
}

static int rt_is_digit(int c)
{
    return c >= '0' && c <= '9';
}

static int rt_is_space(int c)
{
    return c == ' ' || c == '\n' || c == '\r' || c == '\t'
        || c == '\f' || c == '\v';
}

static int rt_digit_value(int c)
{
    if (c >= '0' && c <= '9')
        return c - '0';
    if (c >= 'a' && c <= 'z')
        return c - 'a' + 10;
    if (c >= 'A' && c <= 'Z')
        return c - 'A' + 10;
    return -1;
}

struct RtScanIn {
    const char *buf;
    size_t pos;
    size_t start;
    size_t len;
    int bounded;
};

#define RT_SCAN_LEN_DEFAULT 0
#define RT_SCAN_LEN_HH 1
#define RT_SCAN_LEN_H 2
#define RT_SCAN_LEN_L 3
#define RT_SCAN_LEN_LL 4
#define RT_SCAN_LEN_INTMAX 5
#define RT_SCAN_LEN_SIZE 6
#define RT_SCAN_LEN_PTRDIFF 7
#define RT_SCAN_LEN_LDOUBLE 8

static int rt_scan_peek_at(struct RtScanIn *in, size_t off)
{
    size_t p = in->pos + off;
    if (in->bounded) {
        if (p >= in->len)
            return -1;
    } else if (in->buf[p] == 0) {
        return -1;
    }
    return (unsigned char)in->buf[p];
}

static int rt_scan_peek(struct RtScanIn *in)
{
    return rt_scan_peek_at(in, 0);
}

static int rt_scan_get(struct RtScanIn *in)
{
    int c = rt_scan_peek(in);
    if (c >= 0)
        ++in->pos;
    return c;
}

static void rt_scan_skip_space(struct RtScanIn *in)
{
    while (rt_is_space(rt_scan_peek(in)))
        ++in->pos;
}

static int rt_scan_finish(struct RtScanIn *in, int assigned)
{
    if (assigned == 0 && rt_scan_peek(in) < 0)
        return -1;
    return assigned;
}

static int rt_scan_parse_number(struct RtScanIn *in, int spec, int width,
                                unsigned long long *out, int *negative)
{
    size_t token_start = in->pos;
    int limit = width > 0 ? width : 0x7fffffff;
    int base;
    int digits = 0;
    unsigned long long value = 0;
    int c;
    int d;

    *negative = 0;
    if (limit <= 0)
        return 0;

    c = rt_scan_peek(in);
    if ((c == '-' || c == '+') && limit > 0) {
        *negative = c == '-';
        ++in->pos;
        --limit;
    }

    if (spec == 'o') {
        base = 8;
    } else if (spec == 'x' || spec == 'X' || spec == 'p') {
        base = 16;
        if (limit >= 3 && rt_scan_peek_at(in, 0) == '0'
            && (rt_scan_peek_at(in, 1) == 'x'
                || rt_scan_peek_at(in, 1) == 'X')
            && rt_digit_value(rt_scan_peek_at(in, 2)) >= 0
            && rt_digit_value(rt_scan_peek_at(in, 2)) < 16) {
            in->pos += 2;
            limit -= 2;
        }
    } else if (spec == 'i') {
        base = 10;
        if (limit >= 1 && rt_scan_peek_at(in, 0) == '0') {
            base = 8;
            if (limit >= 3 && (rt_scan_peek_at(in, 1) == 'x'
                               || rt_scan_peek_at(in, 1) == 'X')
                && rt_digit_value(rt_scan_peek_at(in, 2)) >= 0
                && rt_digit_value(rt_scan_peek_at(in, 2)) < 16) {
                base = 16;
                in->pos += 2;
                limit -= 2;
            }
        }
    } else {
        base = 10;
    }

    while (limit > 0) {
        c = rt_scan_peek(in);
        d = rt_digit_value(c);
        if (d < 0 || d >= base)
            break;
        value = value * (unsigned int)base + (unsigned int)d;
        ++in->pos;
        --limit;
        ++digits;
    }

    if (digits == 0) {
        in->pos = token_start;
        return 0;
    }
    *out = *negative ? 0ull - value : value;
    return 1;
}

static void rt_scan_store_int(void *dst, int length, unsigned long long value)
{
    if (length == RT_SCAN_LEN_HH) {
        *(unsigned char *)dst = (unsigned char)value;
    } else if (length == RT_SCAN_LEN_H) {
        *(unsigned short *)dst = (unsigned short)value;
    } else if (length == RT_SCAN_LEN_LL || length == RT_SCAN_LEN_INTMAX) {
        *(unsigned long long *)dst = value;
    } else if (length == RT_SCAN_LEN_SIZE) {
        *(size_t *)dst = (size_t)value;
    } else if (length == RT_SCAN_LEN_PTRDIFF) {
        *(int *)dst = (int)value;
    } else {
        *(unsigned int *)dst = value;
    }
}

static int rt_vscan(struct RtScanIn *in, const char *fmt, va_list ap)
{
    int assigned = 0;

    while (*fmt) {
        int suppress;
        int width;
        int length;
        int spec;

        if (rt_is_space(*fmt)) {
            while (rt_is_space(*fmt))
                ++fmt;
            rt_scan_skip_space(in);
            continue;
        }

        if (*fmt != '%') {
            if (rt_scan_peek(in) != (unsigned char)*fmt)
                return rt_scan_finish(in, assigned);
            ++in->pos;
            ++fmt;
            continue;
        }

        ++fmt;
        if (*fmt == '%') {
            if (rt_scan_peek(in) != '%')
                return rt_scan_finish(in, assigned);
            ++in->pos;
            ++fmt;
            continue;
        }

        suppress = 0;
        if (*fmt == '*') {
            suppress = 1;
            ++fmt;
        }

        width = 0;
        while (rt_is_digit(*fmt)) {
            width = width * 10 + *fmt - '0';
            ++fmt;
        }

        length = RT_SCAN_LEN_DEFAULT;
        if (*fmt == 'h') {
            ++fmt;
            if (*fmt == 'h') {
                length = RT_SCAN_LEN_HH;
                ++fmt;
            } else {
                length = RT_SCAN_LEN_H;
            }
        } else if (*fmt == 'l') {
            ++fmt;
            if (*fmt == 'l') {
                length = RT_SCAN_LEN_LL;
                ++fmt;
            } else {
                length = RT_SCAN_LEN_L;
            }
        } else if (*fmt == 'j') {
            length = RT_SCAN_LEN_INTMAX;
            ++fmt;
        } else if (*fmt == 'z') {
            length = RT_SCAN_LEN_SIZE;
            ++fmt;
        } else if (*fmt == 't') {
            length = RT_SCAN_LEN_PTRDIFF;
            ++fmt;
        } else if (*fmt == 'L') {
            length = RT_SCAN_LEN_LDOUBLE;
            ++fmt;
        }

        spec = *fmt ? *fmt++ : 0;
        if (spec != 'c' && spec != '[' && spec != 'n')
            rt_scan_skip_space(in);

        if (spec == 'd' || spec == 'i' || spec == 'u' || spec == 'x'
            || spec == 'X' || spec == 'o' || spec == 'p') {
            unsigned long long value;
            int negative;
            if (!rt_scan_parse_number(in, spec, width, &value, &negative))
                return rt_scan_finish(in, assigned);
            if (!suppress) {
                void *dst = va_arg(ap, void *);
                if (spec == 'p')
                    *(void **)dst = (void *)value;
                else
                    rt_scan_store_int(dst, length, value);
                ++assigned;
            }
            continue;
        }

        if (spec == 'f' || spec == 'F' || spec == 'e' || spec == 'E'
            || spec == 'g' || spec == 'G' || spec == 'a' || spec == 'A') {
            size_t available = in->bounded ? in->len - in->pos : ~0u;
            size_t used;
            int ok;
            int precision = length == RT_SCAN_LEN_L || length == RT_SCAN_LEN_LDOUBLE ? 53 : 24;
            unsigned long long bits;
            if (width > 0 && (size_t)width < available) available = (size_t)width;
            if (rt_scan_peek(in) < 0) return assigned ? assigned : EOF;
            bits = rt_parse_fp(in->buf + in->pos, available, 1, precision, &used, &ok);
            in->pos += used;
            if (!ok) return assigned; /* Incomplete input item is matching failure, not EOF. */
            if (!suppress) {
                if (precision == 53) {
                    union { double d; unsigned long long u; } value;
                    value.u = bits;
                    if (length == RT_SCAN_LEN_LDOUBLE) *va_arg(ap, long double *) = (long double)value.d;
                    else *va_arg(ap, double *) = value.d;
                } else {
                    union { float f; unsigned int u; } value;
                    value.u = (unsigned int)bits;
                    *va_arg(ap, float *) = value.f;
                }
                ++assigned;
            }
            continue;
        }

        if (spec == 's') {
            char *dst = suppress ? 0 : va_arg(ap, char *);
            int count = 0;
            int limit = width > 0 ? width : 0x7fffffff;
            while (limit > 0 && rt_scan_peek(in) >= 0
                   && !rt_is_space(rt_scan_peek(in))) {
                int c = rt_scan_get(in);
                if (!suppress)
                    dst[count] = (char)c;
                ++count;
                --limit;
            }
            if (count == 0)
                return rt_scan_finish(in, assigned);
            if (!suppress) {
                dst[count] = 0;
                ++assigned;
            }
            continue;
        }

        if (spec == 'c') {
            char *dst = suppress ? 0 : va_arg(ap, char *);
            int count = 0;
            int limit = width > 0 ? width : 1;
            while (count < limit) {
                int c = rt_scan_get(in);
                if (c < 0)
                    return rt_scan_finish(in, assigned);
                if (!suppress)
                    dst[count] = (char)c;
                ++count;
            }
            if (!suppress)
                ++assigned;
            continue;
        }

        if (spec == 'n') {
            if (!suppress) {
                void *dst = va_arg(ap, void *);
                rt_scan_store_int(dst, length,
                                  (unsigned int)(in->pos - in->start));
            }
            continue;
        }

        return rt_scan_finish(in, assigned);
    }
    return assigned;
}

static void rt_fmt_pad(struct RtFmtOut *out, int ch, int count)
{
    while (count-- > 0)
        rt_fmt_putc(out, ch);
}

static void rt_ull_split(unsigned long long value, unsigned int *lo,
                         unsigned int *hi)
{
    union {
        unsigned long long ull;
        unsigned int u32[2];
    } parts;

    parts.ull = value;
    *lo = parts.u32[0];
    *hi = parts.u32[1];
}

static int rt_u64_bit(unsigned int lo, unsigned int hi, int bit)
{
    if (bit < 32)
        return (int)((lo >> bit) & 1u);
    return (int)((hi >> (bit - 32)) & 1u);
}

static int rt_ull_to_decimal_digits(char *buf, unsigned long long value)
{
    unsigned int lo;
    unsigned int hi;
    int count = 1;
    int bit;
    int i;

    rt_ull_split(value, &lo, &hi);
    buf[0] = '0';
    for (bit = 63; bit >= 0; --bit) {
        int carry = rt_u64_bit(lo, hi, bit);
        for (i = 0; i < count; ++i) {
            int digit = (buf[i] - '0') * 2 + carry;
            if (digit >= 10) {
                buf[i] = (char)('0' + digit - 10);
                carry = 1;
            } else {
                buf[i] = (char)('0' + digit);
                carry = 0;
            }
        }
        if (carry)
            buf[count++] = '1';
    }
    while (count > 1 && buf[count - 1] == '0')
        --count;
    return count;
}

static int rt_ull_to_power2_digits(char *buf, unsigned long long value,
                                   int shift, const char *digits)
{
    unsigned int lo;
    unsigned int hi;
    int n = 0;
    int bit;

    rt_ull_split(value, &lo, &hi);
    for (bit = 0; bit < 64; bit += shift) {
        unsigned int digit = 0;
        int i;
        for (i = 0; i < shift && bit + i < 64; ++i)
            digit |= (unsigned int)rt_u64_bit(lo, hi, bit + i) << i;
        buf[n++] = digits[digit];
    }
    while (n > 1 && buf[n - 1] == '0')
        --n;
    return n;
}

static int rt_ull_to_digits(char *buf, unsigned long long value,
                            unsigned int base, int upper)
{
    static const char lower_digits[] = "0123456789abcdef";
    static const char upper_digits[] = "0123456789ABCDEF";
    const char *digits = upper ? upper_digits : lower_digits;

    if (base == 10)
        return rt_ull_to_decimal_digits(buf, value);
    if (base == 16)
        return rt_ull_to_power2_digits(buf, value, 4, digits);
    return rt_ull_to_power2_digits(buf, value, 3, digits);
}

static void rt_fmt_number(struct RtFmtOut *out, unsigned long long value,
                          unsigned int base, int negative, int upper,
                          int width, int precision, int left, int zero,
                          int plus, int space, int alt, int pointer)
{
    char digits[65];
    char prefix[3];
    int digit_count;
    int prefix_len = 0;
    int zero_count;
    int total;
    int i;

    prefix[0] = 0;
    if (negative) {
        prefix[prefix_len++] = '-';
    } else if (plus) {
        prefix[prefix_len++] = '+';
    } else if (space) {
        prefix[prefix_len++] = ' ';
    }

    if (pointer || (alt && value != 0 && (base == 16 || base == 8))) {
        if (base == 16) {
            prefix[prefix_len++] = '0';
            prefix[prefix_len++] = upper ? 'X' : 'x';
        } else if (base == 8) {
            prefix[prefix_len++] = '0';
        }
    }

    digit_count = 0;
    if (!(precision == 0 && value == 0))
        digit_count = rt_ull_to_digits(digits, value, base, upper);

    zero_count = 0;
    if (precision > digit_count)
        zero_count = precision - digit_count;
    total = prefix_len + zero_count + digit_count;

    if (!left && !(zero && precision < 0))
        rt_fmt_pad(out, ' ', width - total);
    rt_fmt_write(out, prefix, (size_t)prefix_len);
    if (!left && zero && precision < 0)
        rt_fmt_pad(out, '0', width - total);
    rt_fmt_pad(out, '0', zero_count);
    for (i = digit_count - 1; i >= 0; --i)
        rt_fmt_putc(out, digits[i]);
    if (left)
        rt_fmt_pad(out, ' ', width - total);
}

static int rt_append_char(char *buf, int pos, int cap, int ch)
{
    if (pos + 1 < cap)
        buf[pos] = (char)ch;
    return pos + 1;
}

static int rt_append_str(char *buf, int pos, int cap, const char *s)
{
    while (*s)
        pos = rt_append_char(buf, pos, cap, *s++);
    return pos;
}

static int rt_append_uint_dec(char *buf, int pos, int cap, unsigned int v)
{
    char tmp[16];
    int n = 0;
    int i;

    do {
        tmp[n++] = (char)('0' + v % 10);
        v /= 10;
    } while (v);
    for (i = n - 1; i >= 0; --i)
        pos = rt_append_char(buf, pos, cap, tmp[i]);
    return pos;
}

static double rt_pow10_int(int n)
{
    double r = 1.0;
    int i;

    if (n >= 0) {
        for (i = 0; i < n; ++i)
            r *= 10.0;
    } else {
        for (i = 0; i < -n; ++i)
            r /= 10.0;
    }
    return r;
}

static int rt_decimal_exp(double x)
{
    int e = 0;

    if (x < 0)
        x = -x;
    if (x == 0.0)
        return 0;
    while (x >= 10.0) {
        x /= 10.0;
        ++e;
    }
    while (x < 1.0) {
        x *= 10.0;
        --e;
    }
    return e;
}

static int rt_append_fixed_abs(char *buf, int pos, int cap, double x,
                               int precision, int trim)
{
    union { double d; unsigned int word[2]; } bits;
    /* Exact finite binary64 -> decimal. Little-endian decimal digits avoid
       truncating the integer part to uint32, including values above 2^64. */
    unsigned char digits[1100];
    int count = 1;
    int exponent, scale, bit, carry, j, cut, up;
    int dot_pos;
    int end_pos;
    int i;

    if (precision < 0)
        precision = 6;
    if (precision > 60)
        precision = 60;
    bits.d = x;
    exponent = (int)((bits.word[1] >> 20) & 2047u);
    if (exponent)
        bits.word[1] |= 0x00100000u;
    bits.word[1] &= 0x001fffffu;
    exponent = (exponent ? exponent - 1023 : -1022) - 52;
    digits[0] = 0;
    for (bit = 52; bit >= 0; --bit) {
        carry = bit >= 32 ? (int)((bits.word[1] >> (bit - 32)) & 1u)
                          : (int)((bits.word[0] >> bit) & 1u);
        for (j = 0; j < count; ++j) {
            int value = digits[j] * 2 + carry;
            digits[j] = (unsigned char)(value % 10);
            carry = value / 10;
        }
        if (carry)
            digits[count++] = (unsigned char)carry;
    }
    scale = exponent < 0 ? -exponent : 0;
    for (i = 0; i < (exponent < 0 ? -exponent : exponent); ++i) {
        carry = 0;
        for (j = 0; j < count; ++j) {
            int value = digits[j] * (exponent < 0 ? 5 : 2) + carry;
            digits[j] = (unsigned char)(value % 10);
            carry = value / 10;
        }
        if (carry)
            digits[count++] = (unsigned char)carry;
    }
    cut = scale - precision;
    if (cut > 0) {
        up = cut <= count && digits[cut - 1] > 5;
        if (cut <= count && digits[cut - 1] == 5) {
            up = cut < count && (digits[cut] & 1);
            for (i = 0; i < cut - 1 && !up; ++i)
                up = digits[i] != 0;
        }
        for (i = 0; i < cut && i < count; ++i)
            digits[i] = 0;
        if (up) {
            while (count <= cut)
                digits[count++] = 0;
            for (i = cut; i < count && digits[i] == 9; ++i)
                digits[i] = 0;
            if (i == count)
                digits[count++] = 1;
            else
                ++digits[i];
        }
    }
    if (count <= scale)
        pos = rt_append_char(buf, pos, cap, '0');
    else
        for (i = count - 1; i >= scale; --i)
            pos = rt_append_char(buf, pos, cap, '0' + digits[i]);
    dot_pos = pos;
    if (precision > 0)
        pos = rt_append_char(buf, pos, cap, '.');
    for (i = 0; i < precision; ++i) {
        int at = scale - 1 - i;
        pos = rt_append_char(buf, pos, cap, '0' + (at >= 0 && at < count ? digits[at] : 0));
    }
    end_pos = pos;
    if (trim) {
        while (end_pos > dot_pos && buf[end_pos - 1] == '0')
            --end_pos;
        if (end_pos > dot_pos && buf[end_pos - 1] == '.')
            --end_pos;
        pos = end_pos;
    }
    return pos;
}

static int rt_append_exp_abs(char *buf, int pos, int cap, double x,
                             int precision, int upper, int trim)
{
    int exp = rt_decimal_exp(x);
    int i;

    if (precision < 0)
        precision = 6;
    if (precision > 60)
        precision = 60;
    /* Scale in bounded steps: 10^-324 itself is not representable. */
    for (i = 0; i < exp; ++i)
        x /= 10.0;
    for (i = 0; i < -exp; ++i)
        x *= 10.0;
    if (x + 0.5 * rt_pow10_int(-precision) >= 10.0) {
        x /= 10.0;
        ++exp;
    }
    pos = rt_append_fixed_abs(buf, pos, cap, x, precision, trim);
    pos = rt_append_char(buf, pos, cap, upper ? 'E' : 'e');
    pos = rt_append_char(buf, pos, cap, exp < 0 ? '-' : '+');
    if (exp < 0)
        exp = -exp;
    if (exp < 10)
        pos = rt_append_char(buf, pos, cap, '0');
    if (exp < 100) {
        pos = rt_append_uint_dec(buf, pos, cap, (unsigned int)exp);
    } else {
        for (i = 1000; i > 1 && exp < i; i /= 10)
            ;
        pos = rt_append_uint_dec(buf, pos, cap, (unsigned int)exp);
    }
    return pos;
}

static void rt_fmt_double(struct RtFmtOut *out, double value, int spec,
                          int width, int precision, int left, int zero,
                          int plus, int space, int alt)
{
    char buf[384];
    int pos = 0;
    union { double d; unsigned int word[2]; } bits;
    int negative;
    int trim = !alt;
    int upper = spec == 'E' || spec == 'G';
    int i;

    bits.d = value;
    negative = (bits.word[1] >> 31) != 0;
    if (value != value) {
        pos = rt_append_str(buf, pos, sizeof buf, upper ? "NAN" : "nan");
    } else {
        if (negative)
            value = -value;
        if (negative)
            pos = rt_append_char(buf, pos, sizeof buf, '-');
        else if (plus)
            pos = rt_append_char(buf, pos, sizeof buf, '+');
        else if (space)
            pos = rt_append_char(buf, pos, sizeof buf, ' ');

        if (((bits.word[1] >> 20) & 2047u) == 2047u) {
            pos = rt_append_str(buf, pos, sizeof buf, upper ? "INF" : "inf");
        } else if (spec == 'f' || spec == 'F') {
            pos = rt_append_fixed_abs(buf, pos, sizeof buf, value,
                                      precision < 0 ? 6 : precision, 0);
            if (alt && precision == 0)
                pos = rt_append_char(buf, pos, sizeof buf, '.');
        } else if (spec == 'e' || spec == 'E') {
            pos = rt_append_exp_abs(buf, pos, sizeof buf, value,
                                    precision < 0 ? 6 : precision, upper, 0);
        } else {
            int prec = precision < 0 ? 6 : precision;
            int exp;
            if (prec == 0)
                prec = 1;
            exp = rt_decimal_exp(value);
            if (exp < -4 || exp >= prec) {
                pos = rt_append_exp_abs(buf, pos, sizeof buf, value,
                                        prec - 1, upper, trim);
            } else {
                int frac = prec - (exp + 1);
                if (frac < 0)
                    frac = 0;
                pos = rt_append_fixed_abs(buf, pos, sizeof buf, value,
                                          frac, trim);
            }
        }
    }

    if (pos >= (int)sizeof buf)
        pos = (int)sizeof buf - 1;
    buf[pos] = 0;
    i = 0;
    if (!left && zero && (buf[0] == '-' || buf[0] == '+' || buf[0] == ' ')) {
        rt_fmt_putc(out, buf[0]);
        i = 1;
    }
    if (!left)
        rt_fmt_pad(out, zero ? '0' : ' ', width - pos);
    for (; i < pos; ++i)
        rt_fmt_putc(out, buf[i]);
    if (left)
        rt_fmt_pad(out, ' ', width - pos);
}

static int rt_vformat(struct RtFmtOut *out, const char *fmt, va_list ap)
{
    while (*fmt) {
        int left;
        int plus;
        int space;
        int alt;
        int zero;
        int width;
        int precision;
        int length;
        int done;
        int spec;

        if (*fmt != '%') {
            rt_fmt_putc(out, *fmt++);
            continue;
        }
        ++fmt;
        if (*fmt == '%') {
            rt_fmt_putc(out, *fmt++);
            continue;
        }

        left = plus = space = alt = zero = 0;
        done = 0;
        while (!done) {
            if (*fmt == '-') {
                left = 1;
                ++fmt;
            } else if (*fmt == '+') {
                plus = 1;
                ++fmt;
            } else if (*fmt == ' ') {
                space = 1;
                ++fmt;
            } else if (*fmt == '#') {
                alt = 1;
                ++fmt;
            } else if (*fmt == '0') {
                zero = 1;
                ++fmt;
            } else {
                done = 1;
            }
        }
        if (left)
            zero = 0;

        width = 0;
        if (*fmt == '*') {
            width = va_arg(ap, int);
            if (width < 0) {
                left = 1;
                zero = 0;
                width = -width;
            }
            ++fmt;
        } else {
            while (rt_is_digit(*fmt)) {
                width = width * 10 + *fmt - '0';
                ++fmt;
            }
        }

        precision = -1;
        if (*fmt == '.') {
            ++fmt;
            precision = 0;
            if (*fmt == '*') {
                precision = va_arg(ap, int);
                if (precision < 0)
                    precision = -1;
                ++fmt;
            } else {
                while (rt_is_digit(*fmt)) {
                    precision = precision * 10 + *fmt - '0';
                    ++fmt;
                }
            }
        }

        length = RT_SCAN_LEN_DEFAULT;
        if (*fmt == 'h') {
            ++fmt;
            if (*fmt == 'h') {
                length = RT_SCAN_LEN_HH;
                ++fmt;
            } else {
                length = RT_SCAN_LEN_H;
            }
        } else if (*fmt == 'l') {
            ++fmt;
            if (*fmt == 'l') {
                length = RT_SCAN_LEN_LL;
                ++fmt;
            } else {
                length = RT_SCAN_LEN_L;
            }
        } else if (*fmt == 'j') {
            length = RT_SCAN_LEN_INTMAX;
            ++fmt;
        } else if (*fmt == 'z') {
            length = RT_SCAN_LEN_SIZE;
            ++fmt;
        } else if (*fmt == 't') {
            length = RT_SCAN_LEN_PTRDIFF;
            ++fmt;
        } else if (*fmt == 'L') {
            ++fmt;
        }

        spec = *fmt ? *fmt++ : 0;
        switch (spec) {
        case 'd':
        case 'i': {
            if (length == RT_SCAN_LEN_LL || length == RT_SCAN_LEN_INTMAX) {
                long long v = va_arg(ap, long long);
                unsigned long long mag =
                    v < 0 ? 0ull - (unsigned long long)v
                          : (unsigned long long)v;
                rt_fmt_number(out, mag, 10, v < 0, 0, width, precision, left,
                              zero, plus, space, 0, 0);
            } else if (length == RT_SCAN_LEN_L || length == RT_SCAN_LEN_PTRDIFF) {
                long v = va_arg(ap, long);
                unsigned long mag =
                    v < 0 ? 0ul - (unsigned long)v : (unsigned long)v;
                rt_fmt_number(out, mag, 10, v < 0, 0, width, precision, left,
                              zero, plus, space, 0, 0);
            } else {
                int v = va_arg(ap, int);
                if (length == RT_SCAN_LEN_HH)
                    v = (signed char)v;
                else if (length == RT_SCAN_LEN_H)
                    v = (short)v;
                unsigned int mag =
                    v < 0 ? 0u - (unsigned int)v : (unsigned int)v;
                rt_fmt_number(out, mag, 10, v < 0, 0, width, precision, left,
                              zero, plus, space, 0, 0);
            }
            break;
        }
        case 'u': {
            if (length == RT_SCAN_LEN_LL || length == RT_SCAN_LEN_INTMAX) {
                unsigned long long v = va_arg(ap, unsigned long long);
                rt_fmt_number(out, v, 10, 0, 0, width, precision, left, zero,
                              0, 0, 0, 0);
            } else if (length == RT_SCAN_LEN_L || length == RT_SCAN_LEN_SIZE
                       || length == RT_SCAN_LEN_PTRDIFF) {
                unsigned long v = va_arg(ap, unsigned long);
                rt_fmt_number(out, v, 10, 0, 0, width, precision, left, zero,
                              0, 0, 0, 0);
            } else {
                unsigned int v = va_arg(ap, unsigned int);
                if (length == RT_SCAN_LEN_HH)
                    v = (unsigned char)v;
                else if (length == RT_SCAN_LEN_H)
                    v = (unsigned short)v;
                rt_fmt_number(out, v, 10, 0, 0, width, precision, left, zero,
                              0, 0, 0, 0);
            }
            break;
        }
        case 'x': {
            if (length == RT_SCAN_LEN_LL || length == RT_SCAN_LEN_INTMAX) {
                unsigned long long v = va_arg(ap, unsigned long long);
                rt_fmt_number(out, v, 16, 0, 0, width, precision, left, zero,
                              0, 0, alt, 0);
            } else if (length == RT_SCAN_LEN_L || length == RT_SCAN_LEN_SIZE
                       || length == RT_SCAN_LEN_PTRDIFF) {
                unsigned long v = va_arg(ap, unsigned long);
                rt_fmt_number(out, v, 16, 0, 0, width, precision, left, zero,
                              0, 0, alt, 0);
            } else {
                unsigned int v = va_arg(ap, unsigned int);
                if (length == RT_SCAN_LEN_HH)
                    v = (unsigned char)v;
                else if (length == RT_SCAN_LEN_H)
                    v = (unsigned short)v;
                rt_fmt_number(out, v, 16, 0, 0, width, precision, left, zero,
                              0, 0, alt, 0);
            }
            break;
        }
        case 'X': {
            if (length == RT_SCAN_LEN_LL || length == RT_SCAN_LEN_INTMAX) {
                unsigned long long v = va_arg(ap, unsigned long long);
                rt_fmt_number(out, v, 16, 0, 1, width, precision, left, zero,
                              0, 0, alt, 0);
            } else if (length == RT_SCAN_LEN_L || length == RT_SCAN_LEN_SIZE
                       || length == RT_SCAN_LEN_PTRDIFF) {
                unsigned long v = va_arg(ap, unsigned long);
                rt_fmt_number(out, v, 16, 0, 1, width, precision, left, zero,
                              0, 0, alt, 0);
            } else {
                unsigned int v = va_arg(ap, unsigned int);
                if (length == RT_SCAN_LEN_HH)
                    v = (unsigned char)v;
                else if (length == RT_SCAN_LEN_H)
                    v = (unsigned short)v;
                rt_fmt_number(out, v, 16, 0, 1, width, precision, left, zero,
                              0, 0, alt, 0);
            }
            break;
        }
        case 'o': {
            if (length == RT_SCAN_LEN_LL || length == RT_SCAN_LEN_INTMAX) {
                unsigned long long v = va_arg(ap, unsigned long long);
                rt_fmt_number(out, v, 8, 0, 0, width, precision, left, zero,
                              0, 0, alt, 0);
            } else if (length == RT_SCAN_LEN_L || length == RT_SCAN_LEN_SIZE
                       || length == RT_SCAN_LEN_PTRDIFF) {
                unsigned long v = va_arg(ap, unsigned long);
                rt_fmt_number(out, v, 8, 0, 0, width, precision, left, zero,
                              0, 0, alt, 0);
            } else {
                unsigned int v = va_arg(ap, unsigned int);
                if (length == RT_SCAN_LEN_HH)
                    v = (unsigned char)v;
                else if (length == RT_SCAN_LEN_H)
                    v = (unsigned short)v;
                rt_fmt_number(out, v, 8, 0, 0, width, precision, left, zero,
                              0, 0, alt, 0);
            }
            break;
        }
        case 'p': {
            unsigned int v = va_arg(ap, unsigned int);
            int pointer_precision = precision < 0 ? 1 : precision;
            rt_fmt_number(out, v, 16, 0, 0,
                          width, pointer_precision, left, zero,
                          0, 0, v != 0, v == 0);
            break;
        }
        case 'c': {
            int ch = va_arg(ap, int);
            if (!left)
                rt_fmt_pad(out, ' ', width - 1);
            rt_fmt_putc(out, ch);
            if (left)
                rt_fmt_pad(out, ' ', width - 1);
            break;
        }
        case 's': {
            const char *s = va_arg(ap, const char *);
            size_t len;
            if (!s)
                s = "(null)";
            len = precision >= 0 ? rt_strnlen(s, (size_t)precision) : strlen(s);
            if (!left)
                rt_fmt_pad(out, ' ', width - (int)len);
            rt_fmt_write(out, s, len);
            if (left)
                rt_fmt_pad(out, ' ', width - (int)len);
            break;
        }
        case 'f':
        case 'F': {
            double v = va_arg(ap, double);
            rt_fmt_double(out, v, spec, width, precision, left, zero,
                          plus, space, alt);
            break;
        }
        case 'e':
        case 'E':
        case 'g':
        case 'G': {
            double v = va_arg(ap, double);
            rt_fmt_double(out, v, spec, width, precision, left, zero,
                          plus, space, alt);
            break;
        }
        case 0:
            --fmt;
            break;
        default:
            rt_fmt_putc(out, '%');
            rt_fmt_putc(out, spec);
            break;
        }
    }
    return out->error ? -1 : (int)out->len;
}

int rt_read(int fd, void *dst, size_t len)
{
    size_t avail;
    size_t n;

    if (rt_stdio_hosted)
        return rt_host_read(fd, dst, len);
    if (!rt_stdio_ready())
        return RT_EINVAL;
    if (fd != RT_STDIN)
        return RT_EBADF;
    if (!dst && len)
        return RT_EINVAL;
    avail = rt_stdin_len - rt_stdin_pos;
    n = len;
    if (n > avail)
        n = avail;
    if (n)
        memcpy(dst, rt_stdin_buf + rt_stdin_pos, n);
    rt_stdin_pos += n;
    return (int)n;
}

int rt_write(int fd, const void *src, size_t len)
{
    if (rt_stdio_hosted)
        return rt_host_write(fd, src, len);
    if (fd == RT_STDOUT)
        return rt_buffer_write(rt_stdout_buf, &rt_stdout_used, src, len);
    if (fd == RT_STDERR)
        return rt_buffer_write(rt_stderr_buf, &rt_stderr_used, src, len);
    return RT_EBADF;
}

int read(int fd, void *dst, size_t len)
{
    return rt_read(fd, dst, len);
}

int write(int fd, const void *src, size_t len)
{
    return rt_write(fd, src, len);
}

int rt_getchar(void)
{
    unsigned char ch;
    if (rt_read(RT_STDIN, &ch, 1) != 1)
        return -1;
    return (int)ch;
}

int getchar(void)
{
    return rt_getchar();
}

int rt_putchar(int ch)
{
    unsigned char c = (unsigned char)ch;
    if (rt_write(RT_STDOUT, &c, 1) != 1)
        return -1;
    return (int)c;
}

int putchar(int ch)
{
    return rt_putchar(ch);
}

int rt_puts(const char *s)
{
    unsigned char nl = '\n';
    size_t len;
    int ret;

    if (!s)
        return RT_EINVAL;
    len = strlen(s);
    ret = rt_write(RT_STDOUT, s, len);
    if (ret < 0)
        return ret;
    if ((size_t)ret != len)
        return RT_ENOSPC;
    ret = rt_write(RT_STDOUT, &nl, 1);
    if (ret != 1)
        return ret < 0 ? ret : RT_ENOSPC;
    return (int)(len + 1);
}

int puts(const char *s)
{
    return rt_puts(s);
}

FILE *__wasm_stdin(void)
{
    return &rt_file_stdin;
}

FILE *__wasm_stdout(void)
{
    return &rt_file_stdout;
}

FILE *__wasm_stderr(void)
{
    return &rt_file_stderr;
}

int fgetc(FILE *f)
{
    unsigned char ch;
    int r;

    if (!f) {
        rt_errno = RT_EBADF;
        return EOF;
    }
    if (f->has_ungot) {
        f->has_ungot = 0;
        return f->ungot;
    }
    if (f->fd == RT_FILE_MEM) {
        if (f->pos >= f->len) {
            f->eof = 1;
            return EOF;
        }
        f->eof = 0;
        return f->buf[f->pos++];
    }
    r = rt_read(f->fd, &ch, 1);
    if (r == 1) {
        f->eof = 0;
        return ch;
    }
    if (r == 0)
        f->eof = 1;
    else {
        f->err = 1;
        rt_errno = -r;
    }
    return EOF;
}

int fputc(int ch, FILE *f)
{
    unsigned char c = (unsigned char)ch;
    int r;

    if (!f) {
        rt_errno = RT_EBADF;
        return EOF;
    }
    if (f->fd == RT_FILE_MEM) {
        r = rt_file_append(f, &c, 1);
        if (r == 1)
            return c;
        f->err = 1;
        if (r < 0)
            rt_errno = -r;
        return EOF;
    }
    r = rt_write(f->fd, &c, 1);
    if (r == 1)
        return c;
    f->err = 1;
    if (r < 0)
        rt_errno = -r;
    return EOF;
}

int ungetc(int ch, FILE *f)
{
    if (!f || ch == EOF)
        return EOF;
    f->ungot = (unsigned char)ch;
    f->has_ungot = 1;
    f->eof = 0;
    return (unsigned char)ch;
}

char *fgets(char *s, int n, FILE *f)
{
    int i;
    int c;

    if (!s || n <= 0 || !f)
        return 0;
    for (i = 0; i < n - 1; ++i) {
        c = fgetc(f);
        if (c == EOF)
            break;
        s[i] = (char)c;
        if (c == '\n') {
            ++i;
            break;
        }
    }
    if (i == 0)
        return 0;
    s[i] = 0;
    return s;
}

/* C89 compatibility for the existing exercises. Like fgets, read through the
   stream so EOF and ungetc agree. An empty line succeeds; immediate EOF leaves
   the destination untouched. Only the terminating newline is discarded. */
char *gets(char *s)
{
    char *p = s;
    int ch;

    if (!s)
        return 0;
    while ((ch = fgetc(&rt_file_stdin)) != EOF && ch != '\n')
        *p++ = (char)ch;
    if (p == s && ch == EOF)
        return 0;
    *p = 0;
    return s;
}

int fputs(const char *s, FILE *f)
{
    size_t len;
    int r;

    if (!s || !f)
        return EOF;
    len = strlen(s);
    if (f->fd == RT_FILE_MEM) {
        r = rt_file_append(f, s, len);
        if (r < 0 || (size_t)r != len) {
            f->err = 1;
            if (r < 0)
                rt_errno = -r;
            return EOF;
        }
        return 0;
    }
    r = rt_write(f->fd, s, len);
    if (r < 0 || (size_t)r != len) {
        f->err = 1;
        if (r < 0)
            rt_errno = -r;
        return EOF;
    }
    return 0;
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *f)
{
    unsigned char *p = ptr;
    size_t total = size * nmemb;
    size_t got = 0;
    int c;

    if (size == 0 || nmemb == 0)
        return 0;
    while (got < total) {
        c = fgetc(f);
        if (c == EOF)
            break;
        p[got++] = (unsigned char)c;
    }
    return got / size;
}

size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *f)
{
    size_t total = size * nmemb;
    int r;

    if (size == 0 || nmemb == 0)
        return 0;
    if (!f)
        return 0;
    if (f->fd == RT_FILE_MEM) {
        r = rt_file_append(f, ptr, total);
        if (r < 0) {
            f->err = 1;
            rt_errno = -r;
            return 0;
        }
        return ((size_t)r) / size;
    }
    r = rt_write(f->fd, ptr, total);
    if (r < 0) {
        f->err = 1;
        rt_errno = -r;
        return 0;
    }
    return ((size_t)r) / size;
}

static int rt_memstream_sync(FILE *f)
{
    unsigned char *p;

    if (!f || !f->memstream)
        return 0;
    p = realloc(f->buf, f->len + 1);
    if (!p && f->len + 1) {
        f->err = 1;
        rt_errno = -RT_ENOSPC;
        return -1;
    }
    f->buf = p;
    f->cap = f->len + 1;
    f->buf[f->len] = 0;
    if (f->memstream_ptr)
        *f->memstream_ptr = (char *)f->buf;
    if (f->memstream_len)
        *f->memstream_len = f->len;
    return 0;
}

int fflush(FILE *f)
{
    if (f && rt_memstream_sync(f) < 0)
        return EOF;
    return 0;
}

int fclose(FILE *f)
{
    int r = 0;

    if (!f)
        return EOF;
    if (f == &rt_file_stdin || f == &rt_file_stdout || f == &rt_file_stderr)
        return 0;
    if (f->memstream) {
        if (rt_memstream_sync(f) < 0)
            r = -1;
    } else if (f->fd == RT_FILE_MEM && f->writable && f->path) {
        r = rt_file_store(f->path, f->buf, f->len);
        if (r < 0) {
            f->err = 1;
            rt_errno = -r;
        }
    }
    if (f->writable && !f->memstream)
        free(f->buf);
    free(f->path);
    free(f);
    return r < 0 ? EOF : 0;
}

FILE *fopen(const char *path, const char *mode)
{
    FILE *f;
    struct RtFileData *data;
    int writable = 0;

    if (!path || !mode) {
        rt_errno = -RT_EINVAL;
        return 0;
    }
    if (mode[0] == 'w' || mode[0] == 'a')
        writable = 1;
    f = malloc(sizeof *f);
    if (!f) {
        rt_errno = -RT_ENOSPC;
        return 0;
    }
    memset(f, 0, sizeof *f);
    f->fd = RT_FILE_MEM;
    f->writable = writable;
    if (writable) {
        f->path = rt_strdup_n(path, strlen(path));
        if (!f->path) {
            free(f);
            rt_errno = -RT_ENOSPC;
            return 0;
        }
        return f;
    }
    data = rt_file_find(path);
    if (!data) {
        free(f);
        rt_errno = -RT_ENOENT;
        return 0;
    }
    f->buf = data->data;
    f->len = data->len;
    f->cap = data->len;
    return f;
}

FILE *fdopen(int fd, const char *mode)
{
    (void)mode;
    if (fd == RT_STDIN)
        return &rt_file_stdin;
    if (fd == RT_STDOUT)
        return &rt_file_stdout;
    if (fd == RT_STDERR)
        return &rt_file_stderr;
    rt_errno = -RT_EBADF;
    return 0;
}

FILE *freopen(const char *path, const char *mode, FILE *f)
{
    (void)path;
    (void)mode;
    return f;
}

FILE *open_memstream(char **ptr, size_t *sizeloc)
{
    FILE *f;

    if (!ptr || !sizeloc) {
        rt_errno = -RT_EINVAL;
        return 0;
    }
    f = malloc(sizeof *f);
    if (!f) {
        rt_errno = -RT_ENOSPC;
        return 0;
    }
    memset(f, 0, sizeof *f);
    f->fd = RT_FILE_MEM;
    f->writable = 1;
    f->memstream = 1;
    f->memstream_ptr = ptr;
    f->memstream_len = sizeloc;
    *ptr = 0;
    *sizeloc = 0;
    return f;
}

FILE *tmpfile(void)
{
    rt_errno = -RT_ENOSYS;
    return 0;
}

char *tmpnam(char *s)
{
    static char name[] = "tmp";
    if (s)
        return strcpy(s, name);
    return name;
}

int remove(const char *path)
{
    (void)path;
    rt_errno = -RT_ENOSYS;
    return -1;
}

int unlink(const char *path)
{
    return remove(path);
}

int open(const char *path, int flags, ...)
{
    (void)path;
    (void)flags;
    rt_errno = -RT_ENOSYS;
    return -1;
}

int close(int fd)
{
    if (fd >= RT_STDIN && fd <= RT_STDERR)
        return 0;
    rt_errno = -RT_EBADF;
    return -1;
}

int lseek(int fd, int offset, int whence)
{
    (void)fd;
    (void)offset;
    (void)whence;
    rt_errno = -RT_EINVAL;
    return -1;
}

int rename(const char *oldpath, const char *newpath)
{
    (void)oldpath;
    (void)newpath;
    rt_errno = -RT_ENOSYS;
    return -1;
}

int feof(FILE *f)
{
    return f ? f->eof : 1;
}

int ferror(FILE *f)
{
    return f ? f->err : 1;
}

void clearerr(FILE *f)
{
    if (f) {
        f->eof = 0;
        f->err = 0;
    }
}

int setvbuf(FILE *f, char *buf, int mode, size_t size)
{
    (void)f;
    (void)buf;
    (void)mode;
    (void)size;
    return 0;
}

int fseek(FILE *f, long offset, int whence)
{
    size_t base;
    size_t pos;

    if (!f || f->fd != RT_FILE_MEM) {
        rt_errno = -RT_EBADF;
        return -1;
    }
    if (whence == SEEK_SET)
        base = 0;
    else if (whence == SEEK_CUR)
        base = f->pos;
    else
        base = f->len;
    if (offset < 0 && (size_t)(-offset) > base) {
        rt_errno = -RT_EINVAL;
        return -1;
    }
    pos = offset < 0 ? base - (size_t)(-offset) : base + (size_t)offset;
    if (pos > f->len)
        pos = f->len;
    f->pos = pos;
    f->eof = 0;
    return 0;
}

long ftell(FILE *f)
{
    if (!f || f->fd != RT_FILE_MEM) {
        rt_errno = -RT_EBADF;
        return -1;
    }
    return (long)f->pos;
}

int vfprintf(FILE *f, const char *fmt, va_list ap)
{
    char buf[4096];
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    size_t len;

    if (n < 0)
        return n;
    len = (size_t)n;
    if (len >= sizeof(buf))
        len = sizeof(buf) - 1;
    if (fwrite(buf, 1, len, f) != len)
        return EOF;
    return n;
}

int fprintf(FILE *f, const char *fmt, ...)
{
    va_list ap;
    int r;

    va_start(ap, fmt);
    r = vfprintf(f, fmt, ap);
    va_end(ap);
    return r;
}

int fscanf(FILE *f, const char *fmt, ...)
{
    char buf[128];
    va_list ap;
    int r;

    if (!fgets(buf, sizeof(buf), f))
        return EOF;
    va_start(ap, fmt);
    r = vsscanf(buf, fmt, ap);
    va_end(ap);
    return r;
}

int vsnprintf(char *dst, size_t n, const char *fmt, va_list ap)
{
    struct RtFmtOut out;
    size_t term;

    out.mode = RT_FMT_TO_BUFFER;
    out.buf = dst;
    out.cap = n;
    out.len = 0;
    out.error = 0;
    rt_vformat(&out, fmt, ap);
    if (n != 0) {
        term = out.len;
        if (term >= n)
            term = n - 1u;
        dst[term] = 0;
    }
    return out.error ? -1 : (int)out.len;
}

int snprintf(char *dst, size_t n, const char *fmt, ...)
{
    va_list ap;
    int ret;

    va_start(ap, fmt);
    ret = vsnprintf(dst, n, fmt, ap);
    va_end(ap);
    return ret;
}

int vsprintf(char *dst, const char *fmt, va_list ap)
{
    struct RtFmtOut out;
    out.mode = RT_FMT_TO_BUFFER;
    out.buf = dst;
    out.cap = RT_NULL;
    out.len = 0;
    out.error = 0;
    rt_vformat(&out, fmt, ap);
    dst[out.len] = 0;
    return out.error ? -1 : (int)out.len;
}

int sprintf(char *dst, const char *fmt, ...)
{
    va_list ap;
    int ret;

    va_start(ap, fmt);
    ret = vsprintf(dst, fmt, ap);
    va_end(ap);
    return ret;
}

int vprintf(const char *fmt, va_list ap)
{
    struct RtFmtOut out;
    out.mode = RT_FMT_TO_STDOUT;
    out.buf = 0;
    out.cap = 0;
    out.len = 0;
    out.error = 0;
    return rt_vformat(&out, fmt, ap);
}

int printf(const char *fmt, ...)
{
    va_list ap;
    int ret;

    va_start(ap, fmt);
    ret = vprintf(fmt, ap);
    va_end(ap);
    return ret;
}

int vsscanf(const char *src, const char *fmt, va_list ap)
{
    struct RtScanIn in;

    if (!src || !fmt)
        return RT_EINVAL;
    in.buf = src;
    in.pos = 0;
    in.start = 0;
    in.len = 0;
    in.bounded = 0;
    return rt_vscan(&in, fmt, ap);
}

int sscanf(const char *src, const char *fmt, ...)
{
    va_list ap;
    int ret;

    va_start(ap, fmt);
    ret = vsscanf(src, fmt, ap);
    va_end(ap);
    return ret;
}

int vscanf(const char *fmt, va_list ap)
{
    struct RtScanIn in;
    int ret;

    if (!rt_stdio_ready())
        return RT_EINVAL;
    if (!fmt)
        return RT_EINVAL;
    in.buf = (const char *)rt_stdin_buf;
    in.pos = rt_stdin_pos;
    in.start = rt_stdin_pos;
    in.len = rt_stdin_len;
    in.bounded = 1;
    ret = rt_vscan(&in, fmt, ap);
    rt_stdin_pos = in.pos;
    return ret;
}

int scanf(const char *fmt, ...)
{
    va_list ap;
    int ret;

    va_start(ap, fmt);
    ret = vscanf(fmt, ap);
    va_end(ap);
    return ret;
}

int abs(int value)
{
    return value < 0 ? -value : value;
}

long labs(long value)
{
    return value < 0 ? -value : value;
}

long long llabs(long long value)
{
    return value < 0 ? -value : value;
}

long long imaxabs(long long value)
{
    return value < 0 ? -value : value;
}

typedef struct { int quot, rem; } div_t;
typedef struct { long quot, rem; } ldiv_t;
typedef struct { long long quot, rem; } lldiv_t;

div_t div(int numer, int denom)
{
    div_t result;
    result.quot = numer / denom;
    result.rem = numer % denom;
    return result;
}

ldiv_t ldiv(long numer, long denom)
{
    ldiv_t result;
    result.quot = numer / denom;
    result.rem = numer % denom;
    return result;
}

lldiv_t lldiv(long long numer, long long denom)
{
    lldiv_t result;
    result.quot = numer / denom;
    result.rem = numer % denom;
    return result;
}

typedef struct {
    long long quot;
    long long rem;
} imaxdiv_t;

imaxdiv_t imaxdiv(long long numer, long long denom)
{
    imaxdiv_t result;
    result.quot = numer / denom;
    result.rem = numer % denom;
    return result;
}

typedef union {
    unsigned long long ull;
    struct {
        unsigned int lo;
        unsigned int hi;
    } s;
} RtU64;

static int rt_u64_ge(const RtU64 *a, const RtU64 *b)
{
    if (a->s.hi != b->s.hi)
        return a->s.hi > b->s.hi;
    return a->s.lo >= b->s.lo;
}

static void rt_u64_sub(RtU64 *a, const RtU64 *b)
{
    unsigned int old_lo = a->s.lo;
    a->s.lo -= b->s.lo;
    a->s.hi -= b->s.hi + (old_lo < b->s.lo);
}

static void rt_u64_shl1(RtU64 *a)
{
    a->s.hi = (a->s.hi << 1) | (a->s.lo >> 31);
    a->s.lo <<= 1;
}

static unsigned int rt_u64_get_bit(const RtU64 *a, int bit)
{
    if (bit < 32)
        return (a->s.lo >> bit) & 1u;
    return (a->s.hi >> (bit - 32)) & 1u;
}

static void rt_u64_set_bit(RtU64 *a, int bit)
{
    if (bit < 32)
        a->s.lo |= 1u << bit;
    else
        a->s.hi |= 1u << (bit - 32);
}

static unsigned long long rt_udivmoddi(unsigned long long n,
                                       unsigned long long d,
                                       unsigned long long *rem)
{
    RtU64 dividend;
    RtU64 divisor;
    RtU64 q;
    RtU64 r;
    int bit;

    dividend.ull = n;
    divisor.ull = d;
    q.ull = 0;
    r.ull = 0;
    if (d == 0) {
        if (rem)
            *rem = 0;
        return 0;
    }
    for (bit = 63; bit >= 0; --bit) {
        rt_u64_shl1(&r);
        r.s.lo |= rt_u64_get_bit(&dividend, bit);
        if (rt_u64_ge(&r, &divisor)) {
            rt_u64_sub(&r, &divisor);
            rt_u64_set_bit(&q, bit);
        }
    }
    if (rem)
        *rem = r.ull;
    return q.ull;
}

unsigned long long __udivdi3(unsigned long long u, unsigned long long v)
{
    return rt_udivmoddi(u, v, 0);
}

unsigned long long __umoddi3(unsigned long long u, unsigned long long v)
{
    unsigned long long r;
    rt_udivmoddi(u, v, &r);
    return r;
}

/* Use unsigned magnitudes so LLONG_MIN never undergoes signed negation.
   Division by zero and LLONG_MIN/-1 are outside the C program contract. */
long long __divdi3(long long u, long long v)
{
    unsigned long long a = (unsigned long long)u;
    unsigned long long b = (unsigned long long)v;
    unsigned long long q;
    if (u < 0) a = 0ull - a;
    if (v < 0) b = 0ull - b;
    q = rt_udivmoddi(a, b, 0);
    if ((u < 0) != (v < 0)) q = 0ull - q;
    return (long long)q;
}

long long __moddi3(long long u, long long v)
{
    unsigned long long a = (unsigned long long)u;
    unsigned long long b = (unsigned long long)v;
    unsigned long long r;
    if (u < 0) a = 0ull - a;
    if (v < 0) b = 0ull - b;
    rt_udivmoddi(a, b, &r);
    if (u < 0) r = 0ull - r;
    return (long long)r;
}

long long __ashrdi3(long long a, int b)
{
    RtU64 u;
    unsigned int sign;
    u.ull = (unsigned long long)a;
    sign = 0u - (u.s.hi >> 31);
    if (b >= 64) {
        u.s.lo = sign;
        u.s.hi = sign;
    } else if (b >= 32) {
        int shift = b - 32;
        u.s.lo = shift ? (u.s.hi >> shift) | (sign << (32 - shift))
                       : u.s.hi;
        u.s.hi = sign;
    } else if (b > 0) {
        u.s.lo = (u.s.lo >> b) | (u.s.hi << (32 - b));
        u.s.hi = (u.s.hi >> b) | (sign << (32 - b));
    }
    return (long long)u.ull;
}

unsigned long long __lshrdi3(unsigned long long a, int b)
{
    RtU64 u;

    u.ull = a;
    if (b >= 64) {
        u.s.lo = 0;
        u.s.hi = 0;
    } else if (b >= 32) {
        u.s.lo = u.s.hi >> (b - 32);
        u.s.hi = 0;
    } else if (b > 0) {
        u.s.lo = (u.s.lo >> b) | (u.s.hi << (32 - b));
        u.s.hi >>= b;
    }
    return u.ull;
}

long long __ashldi3(long long a, int b)
{
    RtU64 u;

    u.ull = (unsigned long long)a;
    if (b >= 64) {
        u.s.lo = 0;
        u.s.hi = 0;
    } else if (b >= 32) {
        u.s.hi = u.s.lo << (b - 32);
        u.s.lo = 0;
    } else if (b > 0) {
        u.s.hi = (u.s.hi << b) | (u.s.lo >> (32 - b));
        u.s.lo <<= b;
    }
    return (long long)u.ull;
}

static unsigned long long rt_strtoull_parse(const char *s, char **endptr,
                                            int base)
{
    const char *start = s;
    const char *digits;
    unsigned long long value = 0;
    int digit;
    int neg = 0;

    while (isspace((unsigned char)*s))
        ++s;
    if (*s == '-' || *s == '+') {
        neg = *s == '-';
        ++s;
    }
    digits = s;
    if (base != 0 && (base < 2 || base > 36)) {
        if (endptr)
            *endptr = (char *)start;
        return 0;
    }
    if ((base == 0 || base == 16) && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
        base = 16;
        s += 2;
        digits = s;
    } else if (base == 0 && *s == '0') {
        base = 8;
    } else if (base == 0) {
        base = 10;
    }
    while ((digit = rt_digit_value((unsigned char)*s)) >= 0 && digit < base) {
        value = value * (unsigned)base + (unsigned)digit;
        ++s;
    }
    if (endptr)
        *endptr = (char *)(s != digits ? s : start);
    return neg ? 0ull - value : value;
}

unsigned long long strtoull(const char *s, char **endptr, int base)
{
    return rt_strtoull_parse(s, endptr, base);
}

long long strtoll(const char *s, char **endptr, int base)
{
    return (long long)rt_strtoull_parse(s, endptr, base);
}

unsigned long strtoul(const char *s, char **endptr, int base)
{
    return (unsigned long)strtoull(s, endptr, base);
}

long strtol(const char *s, char **endptr, int base)
{
    return (long)strtoll(s, endptr, base);
}

long long strtoimax(const char *s, char **endptr, int base)
{
    return strtoll(s, endptr, base);
}

unsigned long long strtoumax(const char *s, char **endptr, int base)
{
    return strtoull(s, endptr, base);
}

int atoi(const char *s)
{
    return (int)strtol(s, 0, 10);
}

long atol(const char *s)
{
    return strtol(s, 0, 10);
}

long long atoll(const char *s)
{
    return strtoll(s, 0, 10);
}

/* Shared, locale-independent C-locale binary32/binary64 parser.
 * Decimal/hex coefficients are exact integers, rounded once, ties-to-even.
 * 2048 significant digits exceed every finite binary64 midpoint's decimal
 * expansion (and hexadecimal significand). Discarded nonzero tails are sticky.
 * Fixed storage/work bounds apply AFTER lexical scanning, not to input length.
 * No host Number/BigInt, floating arithmetic, or fenv dependency is involved. */
#define RT_FP_WORDS 768
#define RT_FP_DIGITS 2048
typedef struct { unsigned short w[RT_FP_WORDS]; int n; } RtFpBig;
typedef union { double d; unsigned long long u; } RtFpDouble;
typedef union { float f; unsigned int u; } RtFpFloat;

static void rt_fp_zero(RtFpBig *a) { a->n = 1; a->w[0] = 0; }
static void rt_fp_trim(RtFpBig *a)
{
    while (a->n > 1 && a->w[a->n - 1] == 0) --a->n;
}
static void rt_fp_muladd(RtFpBig *a, unsigned int m, unsigned int add)
{
    int i; unsigned int carry = add;
    for (i = 0; i < a->n; ++i) {
        unsigned int v = a->w[i] * m + carry;
        a->w[i] = (unsigned short)v;
        carry = v >> 16;
    }
    if (carry) a->w[a->n++] = (unsigned short)carry;
}
static void rt_fp_shift(RtFpBig *a, int shift)
{
    int words = shift / 16, bits = shift % 16, i;
    unsigned int carry = 0;
    if (a->n == 1 && a->w[0] == 0) return;
    if (words) {
        for (i = a->n - 1; i >= 0; --i) a->w[i + words] = a->w[i];
        for (i = 0; i < words; ++i) a->w[i] = 0;
        a->n += words;
    }
    if (bits) {
        for (i = words; i < a->n; ++i) {
            unsigned int v = ((unsigned int)a->w[i] << bits) | carry;
            a->w[i] = (unsigned short)v; carry = v >> 16;
        }
        if (carry) a->w[a->n++] = (unsigned short)carry;
    }
}
static int rt_fp_cmp(const RtFpBig *a, const RtFpBig *b)
{
    int i;
    if (a->n != b->n) return a->n > b->n ? 1 : -1;
    for (i = a->n - 1; i >= 0; --i)
        if (a->w[i] != b->w[i]) return a->w[i] > b->w[i] ? 1 : -1;
    return 0;
}
static void rt_fp_sub(RtFpBig *a, const RtFpBig *b)
{
    int i; unsigned int borrow = 0;
    for (i = 0; i < a->n; ++i) {
        unsigned int x = a->w[i], y = (i < b->n ? b->w[i] : 0) + borrow;
        a->w[i] = (unsigned short)(x - y); borrow = x < y;
    }
    rt_fp_trim(a);
}
static int rt_fp_bitlen(const RtFpBig *a)
{
    unsigned int v = a->w[a->n - 1]; int bits = 0;
    while (v) { ++bits; v >>= 1; }
    return (a->n - 1) * 16 + bits;
}
static unsigned long long rt_fp_round(RtFpBig *num, int power, int decimal,
                                      int precision, int sticky)
{
    RtFpBig den, a, b, t;
    int e, d, i, unit, shift, cmp;
    int emin = precision == 24 ? -126 : -1022;
    int emax = precision == 24 ? 127 : 1023;
    int bias = precision == 24 ? 127 : 1023;
    unsigned long long q = 0;
    unsigned long long inf = precision == 24 ? 0x7f800000ull : 0x7ff0000000000000ull;
    rt_fp_zero(&den); den.w[0] = 1;
    if (decimal) {
        if (power > 0) for (i = 0; i < power; ++i) rt_fp_muladd(num, 5, 0);
        else for (i = 0; i < -power; ++i) rt_fp_muladd(&den, 5, 0);
    }
    d = rt_fp_bitlen(num) - rt_fp_bitlen(&den);
    if (d >= 0) { t = den; rt_fp_shift(&t, d); cmp = rt_fp_cmp(num, &t); }
    else { t = *num; rt_fp_shift(&t, -d); cmp = rt_fp_cmp(&t, &den); }
    if (cmp < 0) --d;
    e = d + power;
    if (e > emax) { rt_errno = 34; return inf; }
    if (e < emin - precision) { rt_errno = 34; return 0; }
    unit = (e < emin ? emin : e) - (precision - 1);
    shift = power - unit;
    a = *num; b = den;
    if (shift >= 0) rt_fp_shift(&a, shift); else rt_fp_shift(&b, -shift);
    d = rt_fp_bitlen(&a) - rt_fp_bitlen(&b);
    for (i = d; i >= 0; --i) {
        t = b; rt_fp_shift(&t, i);
        if (rt_fp_cmp(&a, &t) >= 0) { rt_fp_sub(&a, &t); q |= 1ull << i; }
    }
    t = a; rt_fp_shift(&t, 1); cmp = rt_fp_cmp(&t, &b);
    if (cmp > 0 || (cmp == 0 && (sticky || (q & 1ull)))) ++q;
    if (e < emin) {
        if (rt_fp_bitlen(&a) || sticky) rt_errno = 34;
        return q; /* Carry into the minimum normal is already its bit pattern. */
    }
    if (q == (1ull << precision)) { q >>= 1; ++e; }
    if (e > emax) { rt_errno = 34; return inf; }
    return ((unsigned long long)(e + bias) << (precision - 1))
           | (q - (1ull << (precision - 1)));
}
static int rt_fp_peek(const char *s, size_t at, size_t limit)
{
    return at < limit && s[at] ? (unsigned char)s[at] : -1;
}
static int rt_fp_lower(int c) { return c >= 'A' && c <= 'Z' ? c + 32 : c; }
static int rt_fp_word(const char *s, size_t at, size_t limit, const char *word)
{
    int n = 0;
    while (word[n] && rt_fp_lower(rt_fp_peek(s, at + n, limit)) == word[n]) ++n;
    return n;
}
/* scan=1 consumes the longest prefix of a matching input item, even when an
 * exponent/special token is incomplete. strto*=0 instead rolls back to the
 * longest complete subject sequence. Both return the same correctly rounded
 * bits for complete tokens. Scanner skips whitespace before calling this. */
static unsigned long long rt_parse_fp(const char *s, size_t limit, int scan,
                                      int precision, size_t *used, int *ok)
{
    RtFpBig num;
    size_t p = 0, start, numeric, exponent_at, suffix;
    long long fraction = 0, dropped = 0, significant = 0, power, order;
    int negative = 0, hex = 0, point = 0, digits = 0, stored = 0, sticky = 0;
    int c, digit, base, exponent = 0, exponent_negative = 0, n, i;
    unsigned long long signbit, bits, inf;
    *used = 0; *ok = 0;
    if (!scan) while (rt_is_space(rt_fp_peek(s, p, limit))) ++p;
    start = p;
    c = rt_fp_peek(s, p, limit);
    if (c == '+' || c == '-') { negative = c == '-'; ++p; }
    signbit = negative ? (1ull << (precision == 24 ? 31 : 63)) : 0;
    inf = precision == 24 ? 0x7f800000ull : 0x7ff0000000000000ull;
    n = rt_fp_word(s, p, limit, "inf");
    if (n) {
        if (n < 3) { if (scan) *used = p + n; return 0; }
        p += 3; n = rt_fp_word(s, p, limit, "inity");
        if (n == 5) p += 5;
        else if (scan && n) { *used = p + n; return 0; }
        *used = p; *ok = 1; return signbit | inf;
    }
    n = rt_fp_word(s, p, limit, "nan");
    if (n) {
        if (n < 3) { if (scan) *used = p + n; return 0; }
        p += 3;
        if (rt_fp_peek(s, p, limit) == '(') {
            suffix = p++;
            while ((c = rt_fp_lower(rt_fp_peek(s, p, limit))) == '_'
                    || (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z')) ++p;
            if (rt_fp_peek(s, p, limit) == ')') ++p;
            else if (scan) { *used = p; return 0; }
            else p = suffix;
        }
        *used = p; *ok = 1;
        return signbit | (precision == 24 ? 0x7fc00000ull : 0x7ff8000000000000ull);
    }
    numeric = p;
    if (rt_fp_peek(s, p, limit) == '0'
            && rt_fp_lower(rt_fp_peek(s, p + 1, limit)) == 'x') { hex = 1; p += 2; }
again:
    rt_fp_zero(&num); base = hex ? 16 : 10;
    for (;;) {
        c = rt_fp_peek(s, p, limit);
        if (c == '.' && !point) { point = 1; ++p; continue; }
        digit = rt_digit_value(c);
        if (digit < 0 || digit >= base) break;
        ++digits; ++p;
        if (point) ++fraction;
        if (digit || stored) {
            ++significant;
            if (stored < RT_FP_DIGITS) { rt_fp_muladd(&num, base, digit); ++stored; }
            else { ++dropped; if (digit) sticky = 1; }
        }
    }
    if (!digits) {
        if (hex && !scan) { hex = 0; point = 0; p = numeric; goto again; }
        if (scan) *used = p;
        return 0;
    }
    c = rt_fp_lower(rt_fp_peek(s, p, limit));
    if (c == (hex ? 'p' : 'e')) {
        exponent_at = p++;
        c = rt_fp_peek(s, p, limit);
        if (c == '+' || c == '-') { exponent_negative = c == '-'; ++p; }
        n = 0;
        while ((c = rt_fp_peek(s, p, limit)) >= '0' && c <= '9') {
            if (exponent < 100000000) exponent = exponent * 10 + c - '0';
            ++n; ++p;
        }
        if (!n) {
            if (scan) { *used = p; return 0; }
            p = exponent_at;
        }
    }
    *used = p; *ok = 1;
    if (!stored) return signbit;
    power = (exponent_negative ? -(long long)exponent : (long long)exponent)
            - fraction * (hex ? 4 : 1) + dropped * (hex ? 4 : 1);
    /* Cheap magnitude bounds prevent enormous exponent work. */
    if (hex) order = (long long)rt_fp_bitlen(&num) - 1 + power;
    else order = (long long)stored - 1 + power;
    if (order > (hex ? (precision == 24 ? 128 : 1024) : (precision == 24 ? 39 : 309))) {
        rt_errno = 34; return signbit | inf;
    }
    if (order < (hex ? (precision == 24 ? -151 : -1076) : (precision == 24 ? -47 : -325))) {
        rt_errno = 34; return signbit;
    }
    bits = rt_fp_round(&num, (int)power, !hex, precision, sticky);
    return signbit | bits;
}

double strtod(const char *s, char **endptr)
{
    size_t used; int ok; RtFpDouble v;
    v.u = rt_parse_fp(s, ~0u, 0, 53, &used, &ok);
    if (endptr) *endptr = (char *)s + (ok ? used : 0);
    return v.d;
}
double atof(const char *s) { return strtod(s, 0); }
float strtof(const char *s, char **endptr)
{
    size_t used; int ok; RtFpFloat v;
    v.u = (unsigned int)rt_parse_fp(s, ~0u, 0, 24, &used, &ok);
    if (endptr) *endptr = (char *)s + (ok ? used : 0);
    return v.f;
}
long double strtold(const char *s, char **endptr) { return (long double)strtod(s, endptr); }


long double ldexpl(long double x, int exp)
{
    while (exp > 0) {
        x *= 2.0;
        --exp;
    }
    while (exp < 0) {
        x /= 2.0;
        ++exp;
    }
    return x;
}

char *getenv(const char *name)
{
    (void)name;
    return 0;
}

char *getcwd(char *buf, size_t size)
{
    if (!buf || size == 0) {
        rt_errno = -RT_EINVAL;
        return 0;
    }
    if (size < 2) {
        rt_errno = -RT_ENOSPC;
        return 0;
    }
    buf[0] = '/';
    buf[1] = 0;
    return buf;
}

char *realpath(const char *path, char *resolved_path)
{
    size_t len;
    char *out;

    if (!path) {
        rt_errno = -RT_EINVAL;
        return 0;
    }
    len = strlen(path);
    out = resolved_path ? resolved_path : malloc(len + 1);
    if (!out) {
        rt_errno = -RT_ENOSPC;
        return 0;
    }
    memcpy(out, path, len + 1);
    return out;
}

int system(const char *command)
{
    (void)command;
    rt_errno = -RT_ENOSYS;
    return -1;
}

int rand(void)
{
    rt_rand_state = rt_rand_state * 1103515245u + 12345u;
    return (int)((rt_rand_state >> 1) & RAND_MAX);
}

void srand(unsigned seed)
{
    rt_rand_state = seed ? seed : 1;
}

void abort(void)
{
    rt_host_exit(134);
    for (;;)
        ;
}

void exit(int code)
{
    rt_host_exit(code);
    for (;;)
        ;
}

typedef int time_t;
typedef int clock_t;

struct tm {
    int tm_sec;
    int tm_min;
    int tm_hour;
    int tm_mday;
    int tm_mon;
    int tm_year;
    int tm_wday;
    int tm_yday;
    int tm_isdst;
};

struct timeval {
    time_t tv_sec;
    int tv_usec;
};

struct timezone {
    int tz_minuteswest;
    int tz_dsttime;
};

int rt_host_time_sec(void);
int rt_host_mono_ms(void);

clock_t clock(void)
{
    /* CLOCKS_PER_SEC is 1000 in time.h, so the monotonic millisecond
       counter is already in clock ticks. */
    return (clock_t)rt_host_mono_ms();
}

time_t time(time_t *t)
{
    time_t now = (time_t)rt_host_time_sec();
    if (t)
        *t = now;
    return now;
}

int gettimeofday(struct timeval *tv, struct timezone *tz)
{
    if (tv) {
        tv->tv_sec = time(0);
        tv->tv_usec = 0;
    }
    if (tz) {
        tz->tz_minuteswest = 0;
        tz->tz_dsttime = 0;
    }
    return 0;
}

double difftime(time_t end, time_t beginning)
{
    return (double)end - (double)beginning;
}

static int rt_is_leap(int y)
{
    return (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0));
}

static const int rt_mdays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
static const char *const rt_wday_short[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
static const char *const rt_wday_long[7] = { "Sunday", "Monday", "Tuesday", "Wednesday",
                                             "Thursday", "Friday", "Saturday" };
static const char *const rt_mon_short[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
static const char *const rt_mon_long[12] = { "January", "February", "March", "April", "May", "June",
                                             "July", "August", "September", "October", "November", "December" };

/* Days since 1970-01-01 for a civil date (proleptic Gregorian, Howard Hinnant). */
static int rt_days_from_civil(int y, int m, int d)
{
    int era, yoe, doy, doe;
    y -= (m <= 2);
    era = (y >= 0 ? y : y - 399) / 400;
    yoe = y - era * 400;
    doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}

static void rt_civil_from_days(int z, int *py, int *pm, int *pd)
{
    int era, yoe, y, doy, mp, d, m;
    unsigned doe;
    z += 719468;
    era = (z >= 0 ? z : z - 146096) / 146097;
    doe = (unsigned)(z - era * 146097);
    yoe = (int)((doe - doe / 1460 + doe / 36524 - doe / 146096) / 365);
    y = yoe + era * 400;
    doy = (int)(doe - (365u * (unsigned)yoe + (unsigned)yoe / 4 - (unsigned)yoe / 100));
    mp = (5 * doy + 2) / 153;
    d = doy - (153 * mp + 2) / 5 + 1;
    m = (mp < 10) ? mp + 3 : mp - 9;
    *py = y + (m <= 2);
    *pm = m;
    *pd = d;
}

static struct tm rt_tm;

static void rt_fill_tm(time_t sec)
{
    int days, rem, y, m, d, i, yday;

    days = (int)(sec / 86400);
    rem = (int)(sec % 86400);
    if (rem < 0) {
        rem += 86400;
        days -= 1;
    }
    rt_civil_from_days(days, &y, &m, &d);
    memset(&rt_tm, 0, sizeof(rt_tm));
    rt_tm.tm_sec = rem % 60;
    rt_tm.tm_min = (rem / 60) % 60;
    rt_tm.tm_hour = rem / 3600;
    rt_tm.tm_mday = d;
    rt_tm.tm_mon = m - 1;
    rt_tm.tm_year = y - 1900;
    /* 1970-01-01 was a Thursday (4). */
    rt_tm.tm_wday = (days % 7 + 11) % 7;
    yday = 0;
    for (i = 0; i < m - 1; ++i)
        yday += rt_mdays[i];
    if (m > 2 && rt_is_leap(y))
        yday += 1;
    rt_tm.tm_yday = yday + d - 1;
    rt_tm.tm_isdst = 0;
}

struct tm *localtime(const time_t *t)
{
    if (!t)
        return 0;
    rt_fill_tm(*t);
    return &rt_tm;
}

struct tm *gmtime(const time_t *t)
{
    return localtime(t);
}

time_t mktime(struct tm *tm)
{
    int year, mon, days;
    time_t sec;

    if (!tm)
        return (time_t)-1;
    year = tm->tm_year + 1900;
    mon = tm->tm_mon + 1;
    year += (mon - 1) / 12;
    mon = (mon - 1) % 12 + 1;
    if (mon < 1) {
        mon += 12;
        year -= 1;
    }
    days = rt_days_from_civil(year, mon, tm->tm_mday);
    sec = (time_t)days * 86400 + tm->tm_hour * 3600 + tm->tm_min * 60 + tm->tm_sec;
    rt_fill_tm(sec);
    *tm = rt_tm;
    return sec;
}

struct rt_sf {
    char *s;
    size_t max;
    size_t len;
    int ok;
};

static void rt_sf_ch(struct rt_sf *b, char c)
{
    if (!b->ok)
        return;
    if (b->len + 1 >= b->max) {
        b->ok = 0;
        return;
    }
    b->s[b->len++] = c;
}

static void rt_sf_str(struct rt_sf *b, const char *p)
{
    while (*p)
        rt_sf_ch(b, *p++);
}

static void rt_sf_num(struct rt_sf *b, int val, int width, char pad)
{
    char tmp[16];
    int n = 0, neg = 0;
    unsigned u;

    if (val < 0 && pad == '0')
        neg = 1;
    u = (unsigned)(neg ? -val : val);
    if (u == 0)
        tmp[n++] = '0';
    while (u) {
        tmp[n++] = (char)('0' + u % 10);
        u /= 10;
    }
    if (neg)
        tmp[n++] = '-';
    while (n < width)
        tmp[n++] = pad;
    while (n)
        rt_sf_ch(b, tmp[--n]);
}

size_t strftime(char *s, size_t max, const char *fmt, const struct tm *tm)
{
    struct rt_sf b;
    int h12, week;

    if (!s || max == 0 || !fmt || !tm)
        return 0;
    b.s = s;
    b.max = max;
    b.len = 0;
    b.ok = 1;
    for (; *fmt; ++fmt) {
        if (*fmt != '%') {
            rt_sf_ch(&b, *fmt);
            continue;
        }
        ++fmt;
        switch (*fmt) {
        case '%': rt_sf_ch(&b, '%'); break;
        case 'Y': rt_sf_num(&b, tm->tm_year + 1900, 4, '0'); break;
        case 'C': rt_sf_num(&b, (tm->tm_year + 1900) / 100, 2, '0'); break;
        case 'y': rt_sf_num(&b, (tm->tm_year + 1900) % 100, 2, '0'); break;
        case 'm': rt_sf_num(&b, tm->tm_mon + 1, 2, '0'); break;
        case 'd': rt_sf_num(&b, tm->tm_mday, 2, '0'); break;
        case 'e': rt_sf_num(&b, tm->tm_mday, 2, ' '); break;
        case 'H': rt_sf_num(&b, tm->tm_hour, 2, '0'); break;
        case 'I':
            h12 = tm->tm_hour % 12;
            if (!h12)
                h12 = 12;
            rt_sf_num(&b, h12, 2, '0');
            break;
        case 'M': rt_sf_num(&b, tm->tm_min, 2, '0'); break;
        case 'S': rt_sf_num(&b, tm->tm_sec, 2, '0'); break;
        case 'j': rt_sf_num(&b, tm->tm_yday + 1, 3, '0'); break;
        case 'w': rt_sf_num(&b, tm->tm_wday, 1, '0'); break;
        case 'u': rt_sf_num(&b, tm->tm_wday ? tm->tm_wday : 7, 1, '0'); break;
        case 'U':
            week = (tm->tm_yday + 7 - tm->tm_wday) / 7;
            rt_sf_num(&b, week, 2, '0');
            break;
        case 'W':
            week = (tm->tm_yday + 7 - (tm->tm_wday + 6) % 7) / 7;
            rt_sf_num(&b, week, 2, '0');
            break;
        case 'p': rt_sf_str(&b, tm->tm_hour < 12 ? "AM" : "PM"); break;
        case 'P': rt_sf_str(&b, tm->tm_hour < 12 ? "am" : "pm"); break;
        case 'a': rt_sf_str(&b, rt_wday_short[tm->tm_wday % 7]); break;
        case 'A': rt_sf_str(&b, rt_wday_long[tm->tm_wday % 7]); break;
        case 'b':
        case 'h': rt_sf_str(&b, rt_mon_short[tm->tm_mon % 12]); break;
        case 'B': rt_sf_str(&b, rt_mon_long[tm->tm_mon % 12]); break;
        case 'Z': rt_sf_str(&b, "UTC"); break;
        case 'z': rt_sf_str(&b, "+0000"); break;
        case 'n': rt_sf_ch(&b, '\n'); break;
        case 't': rt_sf_ch(&b, '\t'); break;
        case 'D':
            rt_sf_num(&b, tm->tm_mon + 1, 2, '0');
            rt_sf_ch(&b, '/');
            rt_sf_num(&b, tm->tm_mday, 2, '0');
            rt_sf_ch(&b, '/');
            rt_sf_num(&b, (tm->tm_year + 1900) % 100, 2, '0');
            break;
        case 'F':
            rt_sf_num(&b, tm->tm_year + 1900, 4, '0');
            rt_sf_ch(&b, '-');
            rt_sf_num(&b, tm->tm_mon + 1, 2, '0');
            rt_sf_ch(&b, '-');
            rt_sf_num(&b, tm->tm_mday, 2, '0');
            break;
        case 'T':
            rt_sf_num(&b, tm->tm_hour, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_min, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_sec, 2, '0');
            break;
        case 'R':
            rt_sf_num(&b, tm->tm_hour, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_min, 2, '0');
            break;
        case 'r':
            rt_sf_num(&b, tm->tm_hour % 12 ? tm->tm_hour % 12 : 12, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_min, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_sec, 2, '0');
            rt_sf_ch(&b, ' ');
            rt_sf_str(&b, tm->tm_hour < 12 ? "AM" : "PM");
            break;
        case 's':
            rt_sf_num(&b, rt_days_from_civil(tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday) * 86400
                         + tm->tm_hour * 3600 + tm->tm_min * 60 + tm->tm_sec, 1, '0');
            break;
        case 'c':
            rt_sf_str(&b, rt_wday_short[tm->tm_wday % 7]);
            rt_sf_ch(&b, ' ');
            rt_sf_str(&b, rt_mon_short[tm->tm_mon % 12]);
            rt_sf_ch(&b, ' ');
            rt_sf_num(&b, tm->tm_mday, 2, ' ');
            rt_sf_ch(&b, ' ');
            rt_sf_num(&b, tm->tm_hour, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_min, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_sec, 2, '0');
            rt_sf_ch(&b, ' ');
            rt_sf_num(&b, tm->tm_year + 1900, 4, '0');
            break;
        case 'x':
            rt_sf_num(&b, tm->tm_mon + 1, 2, '0');
            rt_sf_ch(&b, '/');
            rt_sf_num(&b, tm->tm_mday, 2, '0');
            rt_sf_ch(&b, '/');
            rt_sf_num(&b, (tm->tm_year + 1900) % 100, 2, '0');
            break;
        case 'X':
            rt_sf_num(&b, tm->tm_hour, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_min, 2, '0');
            rt_sf_ch(&b, ':');
            rt_sf_num(&b, tm->tm_sec, 2, '0');
            break;
        case 0:
            rt_sf_ch(&b, '%');
            --fmt;
            break;
        default:
            rt_sf_ch(&b, '%');
            rt_sf_ch(&b, *fmt);
            break;
        }
    }
    if (!b.ok)
        return 0;
    b.s[b.len] = 0;
    return b.len;
}

char *asctime(const struct tm *tm)
{
    static char rt_asctime_buf[26];
    const char *w;
    int n = 0, i;

    if (!tm)
        return 0;
    w = rt_wday_short[tm->tm_wday % 7];
    for (i = 0; i < 3; ++i)
        rt_asctime_buf[n++] = w[i];
    rt_asctime_buf[n++] = ' ';
    w = rt_mon_short[tm->tm_mon % 12];
    for (i = 0; i < 3; ++i)
        rt_asctime_buf[n++] = w[i];
    rt_asctime_buf[n++] = ' ';
    /* C11 7.27.3.1：日期字段按 %2d 空格填充（"Jan  1"），不是零填充。 */
    rt_asctime_buf[n++] = tm->tm_mday < 10 ? ' ' : (char)('0' + (tm->tm_mday / 10) % 10);
    rt_asctime_buf[n++] = (char)('0' + tm->tm_mday % 10);
    rt_asctime_buf[n++] = ' ';
    rt_asctime_buf[n++] = (char)('0' + (tm->tm_hour / 10) % 10);
    rt_asctime_buf[n++] = (char)('0' + tm->tm_hour % 10);
    rt_asctime_buf[n++] = ':';
    rt_asctime_buf[n++] = (char)('0' + (tm->tm_min / 10) % 10);
    rt_asctime_buf[n++] = (char)('0' + tm->tm_min % 10);
    rt_asctime_buf[n++] = ':';
    rt_asctime_buf[n++] = (char)('0' + (tm->tm_sec / 10) % 10);
    rt_asctime_buf[n++] = (char)('0' + tm->tm_sec % 10);
    rt_asctime_buf[n++] = ' ';
    for (i = 3; i >= 0; --i)
        rt_asctime_buf[n++] = (char)('0' + ((tm->tm_year + 1900) / (i == 3 ? 1000 : i == 2 ? 100 : i == 1 ? 10 : 1)) % 10);
    rt_asctime_buf[n++] = '\n';
    rt_asctime_buf[n] = 0;
    return rt_asctime_buf;
}

char *ctime(const time_t *t)
{
    if (!t)
        return 0;
    return asctime(localtime(t));
}

struct lconv {
    char *decimal_point;
};

static struct lconv rt_lconv = { "." };

struct lconv *localeconv(void)
{
    return &rt_lconv;
}

char *setlocale(int category, const char *locale)
{
    (void)category;
    (void)locale;
    return "C";
}

typedef void (*sighandler_t)(int);

sighandler_t signal(int sig, sighandler_t handler)
{
    (void)sig;
    return handler;
}

int setjmp(int *env)
{
    (void)env;
    return 0;
}

void longjmp(int *env, int val)
{
    (void)env;
    (void)val;
    abort();
}

int rt_isatty(int fd)
{
    if (rt_stdio_hosted)
        return rt_host_isatty(fd);
    return fd == RT_STDIN;
}

int isatty(int fd)
{
    return rt_isatty(fd);
}

/* CODE-STATION MODIFICATION NOTICE
File: _tcc_test/tcc-source/lib/wasm32-libc.c
This is a locally modified Code Station project version, not an unmodified upstream file.
Upstream basis: 44670/tcc-wasm @ 8bff9fbc019a3008395eec4cda6e90752fb88ed9.
Changes: Numeric conversion, formatted IO, runtime helpers, standard-library additions and time handling.
Development records include batches dated 2026-10-20 through 2026-10-27;
these are batch evidence, not asserted dates of every individual edit.
This notice and the annotated source edition were prepared on 2026-10-31.
Existing copyright, license notices and exceptions remain applicable.
See licenses/LOCAL-MODIFICATIONS-NOTICE.txt and evidence/source-map.json.
END CODE-STATION MODIFICATION NOTICE */
