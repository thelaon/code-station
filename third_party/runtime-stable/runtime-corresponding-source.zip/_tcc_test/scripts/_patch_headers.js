// Keep compatibility declarations in step with the rebuilt local libc.
// qsort/bsearch already have app-local implementations in the upstream header.
const fs = require('fs');
const path = require('path');
const base = require('../wasm/ide-resources.js');

const files = Object.assign({}, base.files);
for (const [key, name, declaration] of [
  ['/include/stdio.h', 'gets', 'char *gets(char *__s);'],
  ['/include/stdlib.h', 'atof', 'double atof(const char *s);'],
  ['/include/stdlib.h', 'div', 'div_t div(int numer, int denom);'],
  ['/include/stdlib.h', 'ldiv', 'ldiv_t ldiv(long numer, long denom);'],
  ['/include/stdlib.h', 'lldiv', 'lldiv_t lldiv(long long numer, long long denom);'],
  ['/include/time.h', 'asctime', 'char *asctime(const struct tm *tm);'],
  ['/include/time.h', 'ctime', 'char *ctime(const time_t *t);'],
]) {
  if (!files[key]) throw new Error('Missing header: ' + key);
  const text = Buffer.from(files[key], base.encoding === 'base64' ? 'base64' : 'utf8').toString('utf8');
  if (new RegExp('\\b' + name + '\\s*\\(').test(text)) continue;
  // Place declarations inside the include guard, before the final #endif.
  const at = text.lastIndexOf('#endif');
  if (at < 0) throw new Error('Missing include guard: ' + key);
  const patched = text.slice(0,at) + declaration + '\n\n' + text.slice(at);
  files[key] = base.encoding === 'base64' ? Buffer.from(patched, 'utf8').toString('base64') : patched;
}
// The exact C conversion core reports range errors through the existing errno.
const errnoKey = '/include/errno.h';
let errnoText = Buffer.from(files[errnoKey], base.encoding === 'base64' ? 'base64' : 'utf8').toString('utf8');
if (!/^#define\s+ERANGE\b/m.test(errnoText)) {
  const at = errnoText.lastIndexOf('#endif');
  if (at < 0) throw new Error('Missing errno include guard');
  errnoText = errnoText.slice(0,at) + '#define ERANGE 34\n\n' + errnoText.slice(at);
  files[errnoKey] = base.encoding === 'base64' ? Buffer.from(errnoText,'utf8').toString('base64') : errnoText;
}
// Match the existing wasm32 integer model and the runtime's fixed C locale.
// Byte-oriented UTF-8 transport does not imply a multibyte C locale API.
for (const [key, macros] of [
  ['/include/limits.h', {
    LLONG_MAX:'9223372036854775807LL',
    LLONG_MIN:'(-LLONG_MAX - 1LL)',
    ULLONG_MAX:'18446744073709551615ULL',
    MB_LEN_MAX:'1',
  }],
  ['/include/stdlib.h', {MB_CUR_MAX:'((size_t)1)'}],
]) {
  if (!files[key]) throw new Error('Missing header: ' + key);
  let text = Buffer.from(files[key], base.encoding === 'base64' ? 'base64' : 'utf8').toString('utf8');
  const lines = Object.entries(macros).filter(([name]) => !new RegExp('^#\\s*define\\s+'+name+'\\b','m').test(text))
    .map(([name,value]) => '#define '+name+' '+value);
  if (!lines.length) continue;
  const at = text.lastIndexOf('#endif');
  if (at < 0) throw new Error('Missing include guard: ' + key);
  text = text.slice(0,at)+lines.join('\n')+'\n\n'+text.slice(at);
  files[key] = base.encoding === 'base64' ? Buffer.from(text,'utf8').toString('base64') : text;
}
// The format fragments follow this resource set's wasm32 stdint typedefs:
// exact/least 8,16 -> char/short; fast 8,16,32 and pointer -> int; 64/max -> long long.
const inttypesKey = '/include/inttypes.h';
let inttypesText = Buffer.from(files[inttypesKey], base.encoding === 'base64' ? 'base64' : 'utf8').toString('utf8');
const formats = {};
for (const bits of [8,16,32,64]) {
  for (const family of ['', 'LEAST', 'FAST']) {
    const suffix = family + bits;
    for (const specifier of ['d','i','o','u','x','X'])
      formats['PRI'+specifier+suffix] = '"'+(bits===64?'ll':'')+specifier+'"';
    const scanLength = bits===64?'ll':family==='FAST'?'':bits===8?'hh':bits===16?'h':'';
    for (const specifier of ['d','i','o','u','x'])
      formats['SCN'+specifier+suffix] = '"'+scanLength+specifier+'"';
  }
}
for (const suffix of ['MAX','PTR']) {
  const length = suffix==='MAX'?'ll':'';
  for (const specifier of ['d','i','o','u','x','X'])
    formats['PRI'+specifier+suffix] = '"'+length+specifier+'"';
  for (const specifier of ['d','i','o','u','x'])
    formats['SCN'+specifier+suffix] = '"'+length+specifier+'"';
}
const inttypesLines = Object.entries(formats).filter(([name]) => !new RegExp('^#\\s*define\\s+'+name+'\\b','m').test(inttypesText))
  .map(([name,value]) => '#define '+name+' '+value);
for (const [name,declaration] of [
  ['imaxabs','intmax_t imaxabs(intmax_t value);'],
  ['imaxdiv','imaxdiv_t imaxdiv(intmax_t numer, intmax_t denom);'],
]) if (!new RegExp('\\b'+name+'\\s*\\(').test(inttypesText)) inttypesLines.push(declaration);
const inttypesAt = inttypesText.lastIndexOf('#endif');
if (inttypesAt < 0) throw new Error('Missing inttypes include guard');
inttypesText = inttypesText.slice(0,inttypesAt)+inttypesLines.join('\n')+'\n\n'+inttypesText.slice(inttypesAt);
files[inttypesKey] = base.encoding === 'base64' ? Buffer.from(inttypesText,'utf8').toString('base64') : inttypesText;
  // C11 规定 difftime 返回 double；上游头文件写成 int，会与重建后的 libc 产生 ABI 不一致。
  {
    const key = '/include/time.h';
    let text = Buffer.from(files[key], base.encoding === 'base64' ? 'base64' : 'utf8').toString('utf8');
    const fixed = text.replace(/\bint\s+difftime\s*\(/, 'double difftime(');
    if (fixed === text) throw new Error('difftime declaration not found in time.h');
    files[key] = base.encoding === 'base64' ? Buffer.from(fixed, 'utf8').toString('base64') : fixed;
  }
  // 与上游 ide-resources.js 保持同一种 UMD 形态：Node 里走 module.exports，
  // 浏览器里挂到 root.TccWasmIdeResources（内联执行时必须能走通这条路）。
  // ABI definitions must follow the compiler source, including va_arg alignment.
  if (!files['/include/tccdefs.h']) throw new Error('Missing embedded tccdefs.h');
  files['/include/tccdefs.h'] = fs.readFileSync(path.join(__dirname, '..', 'tcc-source', 'include', 'tccdefs.h'))
    .toString(base.encoding === 'base64' ? 'base64' : 'utf8');
  const payload = JSON.stringify({ encoding: base.encoding, files }, null, 1);
  fs.writeFileSync(path.join(__dirname, '..', 'wasm', '_ide-resources-patched.js'),
    '/* Generated by scripts/_patch_headers.js: declarations, integer limits, inttypes formats and C-locale bounds. */\n' +
    '(function (root, factory) {\n' +
    '  const resources = factory();\n' +
    '  if (typeof module === "object" && module.exports)\n' +
    '    module.exports = resources;\n' +
    '  else\n' +
    '    root.TccWasmIdeResources = resources;\n' +
    '})(typeof globalThis !== "undefined" ? globalThis : this, function () {\n' +
    '  return ' + payload + ';\n' +
    '});\n', 'utf8');
  console.log('Generated _ide-resources-patched.js (declarations, limits and C-locale bounds; existing qsort retained).');

/* CODE-STATION MODIFICATION NOTICE
File: _tcc_test/scripts/_patch_headers.js
This is a locally modified Code Station project version, not an unmodified upstream file.
Upstream basis: 44670/tcc-wasm @ 8bff9fbc019a3008395eec4cda6e90752fb88ed9.
Changes: Local generator for declarations, integer limits, format macros and C-locale bounds.
Development records include batches dated 2026-10-20 through 2026-10-27;
these are batch evidence, not asserted dates of every individual edit.
This notice and the annotated source edition were prepared on 2026-10-31.
Existing copyright, license notices and exceptions remain applicable.
See licenses/LOCAL-MODIFICATIONS-NOTICE.txt and evidence/source-map.json.
END CODE-STATION MODIFICATION NOTICE */
