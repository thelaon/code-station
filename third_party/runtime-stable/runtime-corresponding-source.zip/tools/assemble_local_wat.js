'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
async function main(){
  const context={console,setTimeout,clearTimeout,TextEncoder,TextDecoder,WebAssembly:Object.create(WebAssembly)};
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(__dirname,'../_tcc_test/wasm/wabt.js'),'utf8'),context);
  const wabt=await context.WabtModule();
  for(let i=2;i<process.argv.length;i+=2){
    const input=process.argv[i],output=process.argv[i+1];
    if(!output)throw new Error('Pass input.wat output.wasm pairs');
    const mod=wabt.parseWat(path.basename(input),fs.readFileSync(input,'utf8'),{
      exceptions:true,multi_value:true,sat_float_to_int:true,mutable_globals:true,sign_extension:true,
      bulk_memory:true,reference_types:true});
    try{mod.resolveNames();mod.validate();fs.writeFileSync(output,Buffer.from(mod.toBinary({write_debug_names:false,canonicalize_lebs:true}).buffer));}
    finally{mod.destroy();}
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
