/* Canonical libc source + backend helper contract, shared by both builders. */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const root = path.resolve(__dirname, '..');
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
function checkSources() {
  const canonical = fs.readFileSync(path.join(root, '_tcc_test/wasm/wasm32-libc.c'));
  const mirror = fs.readFileSync(path.join(root, '_tcc_test/tcc-source/lib/wasm32-libc.c'));
  if (!canonical.equals(mirror)) throw new Error(
    'libc source copies differ. Edit _tcc_test/wasm/wasm32-libc.c, review and synchronize tcc-source/lib/wasm32-libc.c before building.');
  return {canonical:'_tcc_test/wasm/wasm32-libc.c', mirror:'_tcc_test/tcc-source/lib/wasm32-libc.c', sha256:digest(canonical)};
}
function checkBinary(binary) {
  const backend = fs.readFileSync(path.join(root, '_tcc_test/tcc-source/wasm32-gen.c'), 'utf8');
  const body = backend.match(/static int wasm32_is_i64_helper_name\([^]*?\n\}/);
  if (!body) throw new Error('Cannot locate backend i64 helper contract');
  const required = [...new Set([...body[0].matchAll(/"(__\w+)"/g)].map(m => m[1]))];
  if (!required.length) throw new Error('Empty i64 helper contract');
  const module = new WebAssembly.Module(binary);
  const exports = WebAssembly.Module.exports(module);
  const missing = required.filter(name => !exports.some(e => e.name === name && e.kind === 'function'));
  if (missing.length) throw new Error('libc is missing backend i64 helpers: ' + missing.join(', '));
  const invalidImports = WebAssembly.Module.imports(module).filter(i => i.module !== 'env');
  if (invalidImports.length) throw new Error('Unexpected libc imports: ' + JSON.stringify(invalidImports));
  return {required_helpers:required, sha256:digest(binary)};
}
if (require.main === module) {
  try {
    const sources = checkSources();
    if (!process.argv[2]) throw new Error('Usage: node tools/check_tcc_libc.js <libc.wasm|--source-only>');
    const binary = process.argv[2] === '--source-only' ? null : checkBinary(fs.readFileSync(process.argv[2]));
    console.log(JSON.stringify({sources, binary}));
  } catch (e) { console.error(e.message); process.exitCode = 1; }
}
module.exports = {checkSources, checkBinary};
