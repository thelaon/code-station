"""Offline native bootstrap of the matching vendored TCC to the browser target.

GCC is a build dependency only. Both delivered modules still run in the browser.
No upstream build/install/cleanup scripts are executed.
"""
from pathlib import Path
import argparse, hashlib, json, subprocess

ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--gcc',required=True)
    ap.add_argument('--node',required=True)
    ap.add_argument('--output-dir',type=Path,required=True)
    args=ap.parse_args()
    src=ROOT/'_tcc_test/tcc-source'
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    config='#define TCC_VERSION "0.9.28rc"\n#define CONFIG_TCC_STATIC 1\n#define CONFIG_TCC_SEMLOCK 0\n'
    commands=[]
    def run(label,cmd):
        commands.append(cmd)
        result=subprocess.run(cmd,cwd=src,capture_output=True,timeout=120)
        (out/(label+'.log')).write_bytes(result.stdout+result.stderr)
        if result.returncode:
            raise RuntimeError(label+': '+(result.stdout+result.stderr).decode('utf-8','replace'))
    run('libc-source-check',[args.node,str(ROOT/'tools/check_tcc_libc.js'),'--source-only'])
    (src/'config.h').write_text(config,encoding='utf-8')
    native=out/'wasm32-tcc.exe'
    run('gcc',[args.gcc,'-O2','-w','-static','-DTCC_TARGET_WASM32','-DONE_SOURCE=1','-o',str(native),str(src/'tcc.c')])
    flags=['-nostdinc','-Iinclude','-I.','-DONE_SOURCE=1','-DTCC_TARGET_WASM32',
           '-DCONFIG_TCC_STATIC','-DCONFIG_TCC_SEMLOCK=0','-Dinline=',
           '-DCONFIG_TCC_CROSSPREFIX="wasm32-"','-DCONFIG_TCCDIR="/"',
           '-DCONFIG_TCC_SYSINCLUDEPATHS="/include"','-DCONFIG_TCC_LIBPATHS="/"',
           '-DTCC_GITHASH="browser"','-Wl,--wasm-app']
    run('compiler',[str(native),*flags,'-o',str(out/'tcc.wat'),'docs/tcc_browser_bare.c'])
    run('libc',[str(native),'-nostdinc','-Iinclude','-nostdlib','-Wl,--wasm-libc','-o',str(out/'libc.wat'),str(ROOT/'_tcc_test/wasm/wasm32-libc.c')])
    run('assemble',[args.node,str(ROOT/'tools/assemble_local_wat.js'),str(out/'tcc.wat'),str(out/'tcc.wasm'),str(out/'libc.wat'),str(out/'libc.wasm')])
    run('libc-contract',[args.node,str(ROOT/'tools/check_tcc_libc.js'),str(out/'libc.wasm')])
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    report={'scope':'offline build only; GCC bootstraps TCC to WAT, existing bundled WABT assembles both browser modules',
            'commands':commands,'source_files':{str(p.relative_to(ROOT)):digest(p) for p in [src/'config.h',src/'tccgen.c',src/'wasm32-gen.c',ROOT/'_tcc_test/wasm/wasm32-libc.c']},
            'outputs':{n:{'bytes':(out/n).stat().st_size,'sha256':digest(out/n)} for n in ['tcc.wasm','libc.wasm']}}
    (out/'manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report['outputs']))
if __name__=='__main__': main()
